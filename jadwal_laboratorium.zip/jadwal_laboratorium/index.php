<?php
session_start();

// Redirect to login page if the user is not logged in
if (!isset($_SESSION['sslogin'])) {
  header("Location: ./auth/login.php");
  exit;
}

// Include configuration and templates
require_once "config.php";
$title = "Dashboard";
require_once "./templates/header.php";
require_once "./templates/navbar.php";
require_once "./templates/sidebar.php";

// Set the page title

// Fetch data for cards
$queryGuru = "SELECT COUNT(*) as totalGuru FROM tbl_guru";
$resultGuru = $koneksi->query($queryGuru);
$rowGuru = $resultGuru->fetch_assoc();

$queryMatpel = "SELECT COUNT(*) as totalMatpel FROM tbl_matpel";
$resultMatpel = $koneksi->query($queryMatpel);
$rowMatpel = $resultMatpel->fetch_assoc();

$queryKelas = "SELECT COUNT(*) as totalKelas FROM tbl_kelas";
$resultKelas = $koneksi->query($queryKelas);
$rowKelas = $resultKelas->fetch_assoc();
?>

<div id="layoutSidenav_content">
  <main class="container fluid px-4 mt-2">
    <h1 class="mb-2">Dashboard</h1>
    <hr>
    <ol class="breadcrumb mb-2">
      <li class="breadcrumb-item active">Data</li>
    </ol>

    <div class="row">
      <div class="col-md-6">

        <!-- kelas card -->
        <div class="col-xxl-9 col-xl-9 animate__animated animate__fadeInLeft" style="animation-delay: 0.5s;">
          <div class="card info-card kelas-card">
            <a class="navbar-brand" href="<?php BASE_URL ?>kelas/kelas.php">
              <div class="card-body">
                <h5 class="card-title fw-bold">Total Kelas</h5>
                <div class="d-flex align-items-center">
                  <div class="ps-3">
                    <span style="font-size: 40px;" class="text-danger small pt-1 fw-bold"><?= $rowKelas['totalKelas'] ?></span>
                    <span class="text-muted small pt-2 ps-1">Kelas</span>
                  </div>
                </div>
              </div>
            </a>
          </div><!-- akhir kelas Card -->
        </div>

        <!-- Total Guru Card -->
        <div class="col-xxl-9 col-xl-9 my-4 animate__animated animate__fadeInLeft" style="animation-delay: 1s;">
          <div class="card info-card guru-card">
            <a class="navbar-brand" href="<?php BASE_URL ?>guru/guru.php">
              <div class="card-body">
                <h5 class="card-title fw-bold">Total Guru</h5>
                <div class="d-flex align-items-center">
                  <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                    <i class="bi bi-person"></i>
                  </div>
                  <div class="ps-3">
                    <span style="font-size: 40px;" class="text-primary font-weight-bold pt-1 fw-bold"><?= $rowGuru['totalGuru'] ?></span>
                    <span class="text-muted small pt-2 ps-1">Guru</span>
                  </div>
                </div>
              </div>
            </a>
          </div><!-- End Total Guru Card -->
        </div>

        <!-- matpel Card -->
        <div class="col-xxl-9 col-xl-9 my-4 animate__animated animate__fadeInLeft" style="animation-delay: 1.5s;">
          <div class="card info-card matpel-card">
            <a class="navbar-brand" href="<?php BASE_URL ?>matpel/matpel.php">
              <div class="card-body">
                <h5 class="card-title fw-bold">Total Matpel </h5>
                <div class="d-flex align-items-center">
                  <div class="ps-3">
                    <span style="font-size: 40px;" class="text-warning pt-1 fw-bold"><?= $rowMatpel['totalMatpel'] ?></span>
                    <span class="text-muted small pt-2 ps-1">Matpel</span>
                  </div>
                </div>
            </a>
          </div>
        </div><!-- End matpel Card -->
      </div>



    </div>



    <!-- Pie Chart -->
    <div class="col-md-4">
      <div class="card-body">
        <h5 class="card-title font-weight-bold">Data Diagram</h5>
        <canvas id="pieChart" style="max-height: 600px; width: 100%;"></canvas>
        <script>
          document.addEventListener("DOMContentLoaded", () => {
            new Chart(document.querySelector('#pieChart'), {
              type: 'pie',
              data: {
                labels: ['Total Kelas', 'Total Guru', 'Total Matpel'],
                datasets: [{
                  label: 'Jumlah Data',
                  data: [<?= $rowKelas['totalKelas']; ?>, <?= $rowGuru['totalGuru']; ?>, <?= $rowMatpel['totalMatpel']; ?>],
                  backgroundColor: ['rgb(255, 99, 132)', 'rgb(54, 162, 235)', 'rgb(255, 205, 86)'],
                  hoverOffset: 4
                }]
              },
              options: {
                animation: {
                  duration: 2500, // Adjust the duration in milliseconds (e.g., 2000 for 2 seconds)
                },
              },
            });
          });
        </script>
      </div>
    </div><!-- End Pie Chart -->

</div>
</main>
<footer class="py-3 bg-light border mt-4 text-center">
  <div class="container-fluid px-4">
    <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
  </div>
</footer>
</div>

<?php
require_once "./templates/footer.php";
?>