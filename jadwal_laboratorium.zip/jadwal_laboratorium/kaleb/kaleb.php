<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}

require_once "../config.php";

$title = "kepala Lab SMKN 1 RAWAMERTA";

require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";

if (isset($_SESSION["edit"])) {
  echo "<script>
  alert('data berhasil di edit');
  </script>";
  unset($_SESSION["edit"]);
} elseif (isset($_SESSION["succses"])) {
  echo "<script>
  alert('data berhasil di hapus');
  </script>";
  unset($_SESSION["succses"]);
} elseif (isset($_SESSION["failed"])) {
  echo "<script>
  alert('data gagal di hapus');
  </script>";
  unset($_SESSION["failed"]);
}

?>


<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid px-4">
      <h1 class="mt-2">Kepala Laboratorium</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Kepala Lab</li>
      </ol>
      <div class="card mb-4">
        <div class="card-header">
          <i class="fas fa-table me-1"></i>
          Data Kepala Lab
          <a href="add-kaleb.php" class=" btn btn-sm btn-primary float-end"><i class="fa-solid fa-plus me-2"></i>Tambah data</a>
        </div>
        <div class="card-body">
          <table class="table table-bordered table-striped text-center" id="data_table">
            <thead>
              <th class="col col-1">No</th>
              <th>Nama</th>
              <th>Kode Guru</th>
              <th>Alamat</th>
              <th>Aksi</th>
            </thead>
            <tbody>
              <?php
              $no = 1;
              $querylab = mysqli_query($koneksi, "SELECT * FROM tbl_keplab ORDER BY id_keplab ASC");
              while ($data = mysqli_fetch_array($querylab)) {
                // Only display rows with 'level' equal to 'kep-lab'
                // if ($data['level'] == 'kepala-lab') {
              ?>
                  <tr>
                    <th><?= $no++; ?></th>
                    <th><?= $data["nama"]; ?></th>
                    <th><?= $data["kode"]; ?></th>
                    <th><?= $data["alamat"]; ?></th>
                    <th>
                      <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#ModalEdit<?= $no; ?>">
                        <i class="fa-solid fa-pen"></i>
                      </button>
                      <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#ModalDltd<?= $no ?>">
                        <i class="fa-solid fa-trash"></i>
                      </button>
                    </th>
                  </tr>
                  <?php include('./modal_dltd.php') ?>
                  <?php include('./modal_edit.php') ?>
              <?php
                }
              ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>
<?php

require_once "../templates/footer.php";


?>