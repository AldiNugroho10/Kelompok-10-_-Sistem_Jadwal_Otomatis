<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}

require_once "../../config.php";

if (isset($_POST['simpan'])) {
  $nama = trim(htmlspecialchars($_POST['nama']));
  $jjm = trim(htmlspecialchars($_POST['alamat']));
  $email = trim(htmlspecialchars($_POST['email']));
  $alamat = trim(htmlspecialchars($_POST['alamat']));
  $kode = trim(htmlspecialchars($_POST['kode']));
  $username = mysqli_real_escape_string($koneksi, $nama);
  $password = password_hash("default_password", PASSWORD_DEFAULT);

  // Format query dengan benar
  $query = "INSERT INTO tbl_user (username, password, nama, alamat, email, kode, level)
  VALUES ('$username', '$password', '$nama', '$alamat', '$email', '$kode', 'kepala-lab')";

  // Eksekusi query
  $result = mysqli_query($koneksi, $query);

  if ($result) {
      echo "<script>
                  alert('Data Berhasil di Simpan');
              </script>";
              header('location: ../kaleb.php');
  } else {
      echo "Error: " . mysqli_error($koneksi);
      header("Location : ../add-kaleb.php");  }
}


