<?php

session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}

require_once "../../config.php";

if (isset($_POST['submit'])) {
  $id = $_POST['id'];
  $nama = htmlspecialchars($_POST['nama']);
  $kode = htmlspecialchars($_POST['kode']);
  $alamat = htmlspecialchars($_POST['alamat']);

  $query = "UPDATE tbl_keplab SET 
      nama = '$nama',
      kode = '$kode',
      alamat = '$alamat'
  WHERE id_keplab = $id";

  // Memperbarui data di database
  mysqli_query($koneksi, $query);

  $_SESSION['edit'] = '';
  header('location: ../kaleb.php');
}


// require_once "../templates/footer.php";
