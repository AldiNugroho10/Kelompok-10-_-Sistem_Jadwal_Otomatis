<div class="modal fade" id="ModalEdit<?= $no ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="./backend/edit-kaleb.php" method="post" enctype="multipart/form-data">
				<input type="hidden" name="id" value="<?= $data['id_keplab'] ?>">
				<div class="modal-header">
					<h1 class="modal-title fs-5" id="exampleModalLabel">Edit </h1>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<div class="mb-2">
						<label for="nama" class="form-label">Nama :</label>
						<input class="form-control" type="text" name="nama"  id="nama" value="<?= $data['nama']; ?>">
					</div>
					<div class="mb-2">
						<label for="kode" class="form-label">Kode Guru :</label>
						<input class="form-control" type="text" name="kode" id="kode" value="<?= $data['kode']; ?>" required>
					</div>
					<div class="mb-2">
						<label for="alamat" class="form-label">Alamat :</label>
						<input class="form-control" type="text" name="alamat" id="alamat" value="<?= $data['alamat'	]; ?>" required>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					<button type="submit" name="submit" class="btn btn-primary">Simpan</button>
			</form>
		</div>
	</div>
</div>