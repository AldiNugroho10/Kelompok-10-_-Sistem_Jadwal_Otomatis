<div id="layoutSidenav">
  <div id="layoutSidenav_nav" class="collapsed">
    <nav class="sb-sidenav accordion bg-light" style="color: black" id="sidenavAccordion">
      <div class="sb-sidenav-menu">
        <div class="nav" style="height: 100vh; overflow-y: auto;">
          <div class="sb-sidenav-menu-heading">Home</div>
          <a class="nav-link" href="<?= BASE_URL ?>index.php">
            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
            Dashboard
          </a>
          <a href="<?= BASE_URL ?>jadwal/jadwal.php" class="nav-link">
            <div class="sb-nav-link-icon"><i class="fa-regular fa-calendar"></i></div>
            Jadwal
          </a>
          <hr class="mb-0">
          <?php if ($_SESSION['level'] == "kepala-lab" || $_SESSION['level'] == "kepsek") { ?>
          <div class="sb-sidenav-menu-heading">Admin</div>
          <?php } ?>
          <?php if ($_SESSION['level'] == "guru") { ?>
            <div class="sb-sidenav-menu-heading">User</div>
          <?php } ?>
          <?php if ($_SESSION['level'] == "kepala-lab") { ?>
            <a class="nav-link" href="<?= BASE_URL ?>user/user.php">
              <div class="sb-nav-link-icon"><i class="fa-solid fa-user"></i></div>
              User
            </a>
            <a class="nav-link" href="<?= BASE_URL ?>absensi/data-absen.php">
              <div class="sb-nav-link-icon"><i class="fa-solid fa-calendar-week"></i></div>
              Data Absensi
            </a>
            <?php } ?>
          <a class="nav-link" href="<?= BASE_URL ?>user/password.php">
            <div class="sb-nav-link-icon"><i class="fa-solid fa-key"></i></div>
            Ganti Password
          </a>
          <hr class="mb-0">
          <div class="sb-sidenav-menu-heading">Data</div>
          <?php if ($_SESSION['level'] == "kepsek") { ?>
            <a class="nav-link" href="<?= BASE_URL ?>kaleb/kaleb.php">
              <div class="sb-nav-link-icon"><i class="fa-solid fa-user-gear"></i></div>
              Kepala Lab
            </a>
          <?php } ?>
          <?php if ($_SESSION['level'] == "guru") { ?>
            <a class="nav-link" href="<?= BASE_URL ?>absensi/lab.php">
              <div class="sb-nav-link-icon"><i class="fa-solid fa-address-book"></i></div>
              Absensi
            </a>
          <?php } ?>
          <a class="nav-link" href="<?= BASE_URL ?>guru/guru.php">
            <div class="sb-nav-link-icon"><i class="fa-solid fa-chalkboard-user"></i></div>
            Guru
          </a>
          <a class="nav-link" href="<?= BASE_URL ?>matpel/matpel.php">
            <div class="sb-nav-link-icon"><i class="fa-solid fa-book"></i></div>
            Mata Pelajaran
          </a>
          <a class="nav-link" href="<?= BASE_URL ?>kelas/kelas.php">
            <div class="sb-nav-link-icon"><i class="fa-solid fa-people-roof"></i></div>
            Kelas
          </a>
          <hr class="mb-0">
        </div>
      </div>
      <div class="sb-sidenav-footer">
        <div class="small">Logged in as:</div>
        HI <?= $_SESSION['ssUser'] ?>
      </div>
    </nav>
  </div>