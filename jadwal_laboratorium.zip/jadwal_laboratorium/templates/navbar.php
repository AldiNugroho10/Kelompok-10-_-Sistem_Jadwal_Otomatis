<nav class="sb-topnav navbar navbar-expand-lg navbar-dark bg-dark">
  <!-- Navbar Brand-->
  <nav class="navbar navbar-dark bg-body-tertiary text-white">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?= BASE_URL ?>index.php">
        <img src="<?= BASE_URL ?>assets/image/logo.png" alt="Logo" width="25" height="-70" class="d-inline align-text-top">
        <span h-5>SMKN 1 RAWAMERTA</span>
      </a>
    </div>
  </nav>

  <!-- Sidebar Toggle-->
  <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0 text-decoration-none" id="sidebarToggle" href="#!">
    <i class="ri-menu-3-line ri-2x"></i>
  </button>
  <!-- Navbar Search-->
  <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
    <span class="mr-2 d-none d-lg-inline text-white text-capitalize"> Hi <?= $_SESSION['ssUser'] ?></span>
  </form>
  <!-- Navbar-->
  <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
      <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
        <li><a class="dropdown-item" data-bs-toggle="modal" href="#mdlProfileUser">Profile User</a></li>
        <li>
          <hr class="dropdown-divider" />
        </li>
        <li><a class="dropdown-item" href="<?= BASE_URL ?>auth/logout.php">Logout</a></li>
      </ul>
    </li>
  </ul>
</nav>

<!-- ... your navigation code ... -->

<?php
$username = $_SESSION['ssUser'];
$queryUser = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username = '$username'");
$profile = mysqli_fetch_array($queryUser);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $id = $_POST['id_user'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $level = $_POST['level'];
    $query = mysqli_query($koneksi, "UPDATE tbl_user SET nama = '$nama', alamat = '$alamat', level = '$level' WHERE id_user = '$id' ");

    if ($query) {
        $_SESSION['ssUser'] = $username;
        echo "<script>alert('Profil berhasil diperbarui.');</script>";
        header("Location: " . BASE_URL . "index.php");
        exit(); // Pastikan skrip berhenti dieksekusi setelah pengalihan header
    }
}
?>


<div class="modal" tabindex="-1" id="mdlProfileUser">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Profile User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <div class="card mb-3 border-0">
                    <div class="card-body">
                        <div class="mb-5">
                            <h4 class="card-title mb-3 text-capitalize ps-1"><?= $profile['username']?></h4>
                            <hr>
                            <form action="" method="POST">
                                <div class="row">
                                    <label for="nama" class="col-sm-3 col-form-label text-center">Nama:</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control border-0 bg-transparent" id="nama"
                                            name="nama" value="<?= $profile['nama'] ?>">
                                    </div>
                                </div>

                                <input type="hidden" name="id_user" value="<?= $profile['id_user'] ?>">

                                <div class="row">
                                    <label for="jabatan" class="col-sm-3 col-form-label text-center pe-0">Jabatan:</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control border-0 bg-transparent" id="jabatan"
                                            name="level" value="<?= $profile['level'] ?>" readonly>
                                    </div>
                                </div>

                                <div class="row">
                                    <label for="alamat" class="col-sm-3 col-form-label text-center pe-0">Alamat:</label>
                                    <div class="col-sm-9">
                                        <textarea class="form-control border-0 bg-transparent" id="alamat" name="alamat"
                                            cols="30" rows="2"><?= $profile['alamat'] ?></textarea>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
            </div>
            </form>
        </div>
    </div>
</div>
