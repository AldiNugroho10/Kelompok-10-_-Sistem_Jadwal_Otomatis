-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Jan 2024 pada 03.26
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `backend`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_absensi`
--

CREATE TABLE `tbl_absensi` (
  `id` int(11) NOT NULL,
  `nama_absensi` varchar(128) NOT NULL,
  `waktu_absen` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_absensi`
--

INSERT INTO `tbl_absensi` (`id`, `nama_absensi`, `waktu_absen`) VALUES
(1, 'hadir', '2024-01-05 19:15:22'),
(2, 'alfa', '2024-01-05 19:15:22'),
(3, 'izin', '2024-01-05 19:15:22'),
(4, 'sakit', '2024-01-05 19:15:22'),
(5, 'belum_absen', '2024-01-05 19:15:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_guru`
--

CREATE TABLE `tbl_guru` (
  `id` int(11) NOT NULL,
  `nama_guru` varchar(255) NOT NULL,
  `nrp_guru` varchar(128) NOT NULL,
  `jjm` varchar(128) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_guru`
--

INSERT INTO `tbl_guru` (`id`, `nama_guru`, `nrp_guru`, `jjm`, `id_user`) VALUES
(33, 'ALDI', '289478', '26', 83);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_hari`
--

CREATE TABLE `tbl_hari` (
  `id` int(11) NOT NULL,
  `nama_hari` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_hari`
--

INSERT INTO `tbl_hari` (`id`, `nama_hari`) VALUES
(1, 'Senin'),
(2, 'Selasa'),
(3, 'Rabu'),
(4, 'Kamis'),
(5, 'Jumat');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_jadwal`
--

CREATE TABLE `tbl_jadwal` (
  `id_jadwal` int(11) NOT NULL,
  `id_hari` int(11) NOT NULL,
  `id_mata_pelajaran` int(11) NOT NULL,
  `id_guru` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `jam` time NOT NULL,
  `tanggal` date DEFAULT NULL,
  `id_absensi` int(11) NOT NULL,
  `id_ruang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_jadwal`
--

INSERT INTO `tbl_jadwal` (`id_jadwal`, `id_hari`, `id_mata_pelajaran`, `id_guru`, `id_kelas`, `jam`, `tanggal`, `id_absensi`, `id_ruang`) VALUES
(202, 3, 2, 33, 6, '05:46:00', '2024-01-07', 5, 1),
(203, 1, 5, 33, 6, '07:58:00', '2024-01-07', 1, 1),
(204, 2, 3, 33, 5, '08:41:00', '2024-01-07', 5, 1),
(205, 4, 5, 33, 5, '08:47:00', '2024-01-01', 5, 2);

--
-- Trigger `tbl_jadwal`
--
DELIMITER $$
CREATE TRIGGER `trg_insert_rekap_absen` AFTER INSERT ON `tbl_jadwal` FOR EACH ROW BEGIN
  -- Insert data ke tbl_rekap_absen
  INSERT INTO tbl_rekap_absen (id_jadwal, tanggal)
  VALUES (NEW.id_jadwal, NEW.tanggal)
  ON DUPLICATE KEY UPDATE
    id_jadwal = VALUES(id_jadwal), tanggal = VALUES(tanggal);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kelas`
--

CREATE TABLE `tbl_kelas` (
  `id` int(11) NOT NULL,
  `nama_kelas` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_kelas`
--

INSERT INTO `tbl_kelas` (`id`, `nama_kelas`) VALUES
(5, 'XI IPS 2'),
(6, 'XI IPS 3'),
(7, 'XII IPA 1'),
(9, 'XII IPA 2'),
(10, 'XII IPS 1'),
(12, 'XII IPS 3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_keplab`
--

CREATE TABLE `tbl_keplab` (
  `id_keplab` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `kode` varchar(225) NOT NULL,
  `status_deactived_tmu` tinyint(4) NOT NULL,
  `status_deleted_tmu` tinyint(4) NOT NULL,
  `created_by_tmu` int(11) NOT NULL,
  `created_date_tmu` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_by_tmu` int(11) NOT NULL,
  `updated_date_tm` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_keplab`
--

INSERT INTO `tbl_keplab` (`id_keplab`, `nama`, `alamat`, `kode`, `status_deactived_tmu`, `status_deleted_tmu`, `created_by_tmu`, `created_date_tmu`, `updated_by_tmu`, `updated_date_tm`, `id_user`) VALUES
(45, 'ajrak', 'krw', 'kode_default', 0, 0, 92, '2024-01-06 13:56:36', 92, '2024-01-06 13:56:36', 92),
(46, 'caca ajah', 'krw', 'kode_default', 0, 0, 95, '2024-01-06 22:11:30', 95, '2024-01-06 22:11:30', 95);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kepsek`
--

CREATE TABLE `tbl_kepsek` (
  `id_kepsek` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `nrp` varchar(128) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_kepsek`
--

INSERT INTO `tbl_kepsek` (`id_kepsek`, `nama`, `nrp`, `id_user`) VALUES
(28, 'groho', '134234', 93),
(29, 'Aldo Herwindo', '9384950', 94);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_matpel`
--

CREATE TABLE `tbl_matpel` (
  `id` int(11) NOT NULL,
  `nama_matpel` varchar(255) NOT NULL,
  `kode_matpel` varchar(20) NOT NULL,
  `jam` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_matpel`
--

INSERT INTO `tbl_matpel` (`id`, `nama_matpel`, `kode_matpel`, `jam`) VALUES
(2, 'Matematika', '', NULL),
(3, 'IPA', '', NULL),
(5, 'Pendidikan Pancasila dan Kewarganegaraan', '', NULL),
(6, 'Seni Budaya', '', NULL),
(7, 'Pendidikan Jasmani, Olahraga, dan Kesehatan', '', NULL),
(8, 'Bahasa Inggris', '', NULL),
(9, 'Prakarya dan Kewirausahaan', '', NULL),
(10, 'Agama dan Budi Pekerti', '', NULL),
(11, 'PPKN', '445', NULL),
(12, 'hvhj', 'jjnkjb', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_rekap_absen`
--

CREATE TABLE `tbl_rekap_absen` (
  `id_history` int(11) NOT NULL,
  `id_jadwal` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `status_absensi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_rekap_absen`
--

INSERT INTO `tbl_rekap_absen` (`id_history`, `id_jadwal`, `tanggal`, `status_absensi`) VALUES
(154, 205, '2024-01-07', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_ruang`
--

CREATE TABLE `tbl_ruang` (
  `id_ruang` int(11) NOT NULL,
  `nama_ruang` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_ruang`
--

INSERT INTO `tbl_ruang` (`id_ruang`, `nama_ruang`) VALUES
(1, 'tkj_1'),
(2, 'tkj_2'),
(3, 'tkj_3'),
(4, 'tkj_4\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `alamat` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `level` enum('kepala-lab','kepsek','guru') NOT NULL,
  `nrp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`, `nama`, `alamat`, `email`, `kode`, `level`, `nrp`) VALUES
(50, 'rajra', '$2y$10$wvKKO6ngfJryzWNMXQReXOuuxdm.DsO8YgLuoNXrlI.zoUNwHy.02', 'rajran', 'karawang', 'rajran@Gmail.com', '', 'guru', 9),
(58, 'dapal', '$2y$10$jnJ1hSx9YcVeERT5KEYDQOZJ7AvWYR4zJDw9cuXxz3I52fHDLO7Yq', 'nl', 'lk l', 'dapa@gmail.com', '', 'kepsek', 0),
(61, 'sen', '$2y$10$bPjZUUgMQXjQgZxtn0G9o.51uy2AkR5SYO0p4YGW5ZVHfZMyxMFoq', 'bkjbjlNKJk', ',;l,', 'nnkm;', '', 'kepsek', 0),
(78, 'aldi', '$2y$10$1xPsnXU1mLIvWrCOJbfdWuJOThph3i6jT/iS5K8sKn0Q3fEQD/HM6', 'aldi', 'aldi', 'aldi', '', 'guru', 0),
(82, 'dapam', '$2y$10$owQRU.o68DWPR54XH1nBHeFTGWYOgpyJo5VLtiYlaj65KhJ4VyHR6', 'dapak', 'krw', 'krw', '', 'guru', 9),
(83, 'ALDIN', '$2y$10$rTmECl.WWsKCUo3aGYbfL.yqQtJ9fc6rLAb0ixzDAIQDgGrTmjazW', 'ALDI', 'karawang', 'aldi@gmail.com', '', 'guru', 289478),
(92, 'ajrak', '$2y$10$2pW8YTepTOv1VndYoYzStenv/.xHZwTSPo1Q/IUfXbCg7dHtJ4stG', 'ajrak', 'krw', 'ajra@Gmail.com', '', 'kepala-lab', 877687),
(93, 'kambing', '$2y$10$/J5Dn9RpMAjfSvVP9tEpT.kGe8nTqU50dDI3JNJFW0H.Vpy3NQeYK', 'groho', 'apa', 'krew@gmail.com', '', 'kepsek', 134234),
(94, 'aldo', '$2y$10$OXXAykd3DPuGpD8r6gOt1uyNO0r1N52qxRVtfFlD7Ht1.hhncQ7qy', 'Aldo Herwindo', 'krw', 'aldo@gmail.com', '', 'kepsek', 9384950),
(95, 'gloho', '$2y$10$3di8aztyM7kyDMtV8KuTpedHXOhKQUZHPpWCFjntXi0zbT5r9sfny', 'caca ajah', 'krw', 'caca@gmail.com', '', 'kepala-lab', 948590);

--
-- Trigger `tbl_user`
--
DELIMITER $$
CREATE TRIGGER `after_insert_user_guru` AFTER INSERT ON `tbl_user` FOR EACH ROW BEGIN
    IF NEW.level = 'guru' THEN
        INSERT INTO tbl_guru (id_user, nama_guru, nrp_guru, jjm)
        VALUES (NEW.id_user, NEW.nama, NEW.nrp, ''); -- Sesuaikan kolom yang sesuai
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_user_keplab` AFTER INSERT ON `tbl_user` FOR EACH ROW BEGIN
    IF NEW.level = 'kepala-lab' THEN
        -- Insert into tbl_keplab
        INSERT INTO tbl_keplab (nama, alamat, kode, status_deactived_tmu, status_deleted_tmu, created_by_tmu, created_date_tmu, updated_by_tmu, updated_date_tm, id_user)
        VALUES (NEW.nama, NEW.alamat, 'kode_default', 0, 0, NEW.id_user, NOW(), NEW.id_user, NOW(), NEW.id_user); -- Sesuaikan kolom yang sesuai
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_user_kepsek` AFTER INSERT ON `tbl_user` FOR EACH ROW BEGIN
    IF NEW.level = 'kepsek' THEN
        -- Insert into tbl_kepsek
        INSERT INTO tbl_kepsek (nama, nrp, id_user)
        VALUES (NEW.nama, NEW.nrp, NEW.id_user); -- Sesuaikan kolom yang sesuai
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_delete_user` BEFORE DELETE ON `tbl_user` FOR EACH ROW BEGIN
    -- Hapus dari tbl_guru
    DELETE FROM `tbl_guru` WHERE `id_user` = OLD.`id_user`;

    -- Hapus dari tbl_keplab
    DELETE FROM `tbl_keplab` WHERE `id_user` = OLD.`id_user`;

    -- Hapus dari tbl_kepsek
    DELETE FROM `tbl_kepsek` WHERE `id_user` = OLD.`id_user`;

END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_absensi`
--
ALTER TABLE `tbl_absensi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_guru`
--
ALTER TABLE `tbl_guru`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `tbl_hari`
--
ALTER TABLE `tbl_hari`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_jadwal`
--
ALTER TABLE `tbl_jadwal`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD UNIQUE KEY `id_hari` (`id_hari`,`id_mata_pelajaran`,`id_guru`,`id_kelas`),
  ADD KEY `id_kelas` (`id_kelas`),
  ADD KEY `id_mata_pelajaran` (`id_mata_pelajaran`),
  ADD KEY `id_guru` (`id_guru`),
  ADD KEY `id_absensi` (`id_absensi`),
  ADD KEY `id_ruang` (`id_ruang`);

--
-- Indeks untuk tabel `tbl_kelas`
--
ALTER TABLE `tbl_kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_keplab`
--
ALTER TABLE `tbl_keplab`
  ADD PRIMARY KEY (`id_keplab`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `tbl_kepsek`
--
ALTER TABLE `tbl_kepsek`
  ADD PRIMARY KEY (`id_kepsek`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `tbl_matpel`
--
ALTER TABLE `tbl_matpel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_rekap_absen`
--
ALTER TABLE `tbl_rekap_absen`
  ADD PRIMARY KEY (`id_history`),
  ADD KEY `id_jadwal` (`id_jadwal`);

--
-- Indeks untuk tabel `tbl_ruang`
--
ALTER TABLE `tbl_ruang`
  ADD PRIMARY KEY (`id_ruang`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_absensi`
--
ALTER TABLE `tbl_absensi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `tbl_guru`
--
ALTER TABLE `tbl_guru`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT untuk tabel `tbl_hari`
--
ALTER TABLE `tbl_hari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `tbl_jadwal`
--
ALTER TABLE `tbl_jadwal`
  MODIFY `id_jadwal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

--
-- AUTO_INCREMENT untuk tabel `tbl_kelas`
--
ALTER TABLE `tbl_kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `tbl_keplab`
--
ALTER TABLE `tbl_keplab`
  MODIFY `id_keplab` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT untuk tabel `tbl_kepsek`
--
ALTER TABLE `tbl_kepsek`
  MODIFY `id_kepsek` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT untuk tabel `tbl_matpel`
--
ALTER TABLE `tbl_matpel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `tbl_rekap_absen`
--
ALTER TABLE `tbl_rekap_absen`
  MODIFY `id_history` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;

--
-- AUTO_INCREMENT untuk tabel `tbl_ruang`
--
ALTER TABLE `tbl_ruang`
  MODIFY `id_ruang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tbl_guru`
--
ALTER TABLE `tbl_guru`
  ADD CONSTRAINT `tbl_guru_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_jadwal`
--
ALTER TABLE `tbl_jadwal`
  ADD CONSTRAINT `tbl_jadwal_ibfk_2` FOREIGN KEY (`id_kelas`) REFERENCES `tbl_kelas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_jadwal_ibfk_3` FOREIGN KEY (`id_mata_pelajaran`) REFERENCES `tbl_matpel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_jadwal_ibfk_4` FOREIGN KEY (`id_hari`) REFERENCES `tbl_hari` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_jadwal_ibfk_5` FOREIGN KEY (`id_guru`) REFERENCES `tbl_guru` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_jadwal_ibfk_6` FOREIGN KEY (`id_absensi`) REFERENCES `tbl_absensi` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_jadwal_ibfk_7` FOREIGN KEY (`id_ruang`) REFERENCES `tbl_ruang` (`id_ruang`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_keplab`
--
ALTER TABLE `tbl_keplab`
  ADD CONSTRAINT `tbl_keplab_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_kepsek`
--
ALTER TABLE `tbl_kepsek`
  ADD CONSTRAINT `tbl_kepsek_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tbl_rekap_absen`
--
ALTER TABLE `tbl_rekap_absen`
  ADD CONSTRAINT `tbl_rekap_absen_ibfk_1` FOREIGN KEY (`id_jadwal`) REFERENCES `tbl_jadwal` (`id_jadwal`) ON DELETE CASCADE ON UPDATE CASCADE;

DELIMITER $$
--
-- Event
--
CREATE DEFINER=`root`@`localhost` EVENT `update_mingguan` ON SCHEDULE EVERY 1 WEEK STARTS '2024-01-07 08:38:05' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
  -- Update id_absensi menjadi 5 untuk setiap record pada tbl_jadwal
  UPDATE tbl_jadwal SET id_absensi = 5;
END$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
