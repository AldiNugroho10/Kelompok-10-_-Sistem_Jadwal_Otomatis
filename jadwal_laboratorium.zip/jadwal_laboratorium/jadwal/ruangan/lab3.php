<?php

session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}
require_once '../modal/backend/function.php'; // Include the TKJ2 class
require_once '../../config.php';

$tkj3 = new TKJ3($koneksi);
$tkj3Data = $tkj3->fetchJadwalData(3); // Assuming 1 is the ID for TKJ1 room
$title = "kepala Lab SMKN 1 RAWAMERTA";

require_once "../../templates/header.php";
require_once "../../templates/navbar.php";
require_once "../../templates/sidebar.php";
?>
<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid px-4">
      <h1 class="mt-2">Jadwal Pelajaran</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../../index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Jadwal Pelajaran</li>
      </ol>
      <div class="card mb-4">
        <div class="card-header">
          <i class="fas fa-table me-1"></i>
          Data Mata Pelajaran
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered table-striped text-center" id="data_table">
              <thead>
                <td class="col col-1 text-center">No</td>
                <th>Hari</th>
                <th>Mata Pelajaran</th>
                <th>Nama Guru</th>
                <th>Jam</th>
                <th>Kelas</th>
                <?php if ($_SESSION['level'] != "guru") { ?>
                  <th>Status</th>
                <?php } ?>
                <?php if ($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek") { ?>
                  <th>Aksi</th>
                <?php } ?>
              </thead>
              <tbody>
                <?php
                $no = 1;
                foreach ($tkj3Data as $data) {
                ?>
                  <tr>
                    <th><?= $no++; ?></th>
                    <td><?= $data["nama_hari"]; ?></td>
                    <td><?= $data["nama_matpel"]; ?></td>
                    <td><?= $data["nama_guru"]; ?></td>
                    <td><?= date('H:i', strtotime($data["jam"])); ?></td>
                    <td><?= $data["nama_kelas"]; ?></td>
                    <?php if ($_SESSION['level'] != "guru") { ?>
                      <td><span class="badge <?= $tkj2->getStatusBadgeClass($data['nama_absensi']); ?>"><?= $data["nama_absensi"]; ?></span></td>
                      <td>
                        <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#ModalEdit<?= $no; ?>">
                          <i class="fa-solid fa-pen"></i>
                        </button>
                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#ModalDltd<?= $no ?>">
                          <i class="fa-solid fa-trash"></i>
                        </button>
                      </td>
                      <?php include './../Modal.php'; ?>
                  </tr>
                <?php } ?>
              <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>



<?php
require_once "../../templates/footer.php";
?>