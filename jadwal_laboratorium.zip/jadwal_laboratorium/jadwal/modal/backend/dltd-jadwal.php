<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
	header("Location: ./auth/login.php");
	exit;
}

require_once "../../../config.php";

if (isset($_POST['submit'])) {
	$id = $_POST['id_jadwal'];

	$result = mysqli_query($koneksi, "DELETE FROM tbl_jadwal WHERE id_jadwal = $id");

	if ($result) {
		$_SESSION['succses'] = '';
	} else {
		$_SESSION['failed'] = '';
	}
	echo '<script>';
        echo 'alert("Data Berhasil di hapus");';
        echo 'window.location.href = "' . BASE_URL . '/jadwal/jadwal.php";';
        echo '</script>';
}
