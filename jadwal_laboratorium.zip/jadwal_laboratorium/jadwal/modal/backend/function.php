<?php
// require_once "templates/header.php";
// require_once "templates/navbar.php";
// require_once "templates/sidebar.php";


class Database {
    private $host = 'localhost';
    private $username = 'root';
    private $password = '';
    private $database = 'backend';
    public $koneksi;

    public function __construct() {
        $this->koneksi = new mysqli($this->host, $this->username, $this->password, $this->database);
        if ($this->koneksi->connect_error) {
            die("Connection failed: " . $this->koneksi->connect_error);
        }
    }

    public function getConnection() {
        return $this->koneksi;
}
}
class Jadwal
{
    protected $koneksi;

    public function __construct($koneksi)
    {
        $this->koneksi = $koneksi;
    }

    public function getStatusBadgeClass($nama_absensi)
    {
        switch ($nama_absensi) {
          case "hadir":
            return "bg-success";
          case "sakit":
            return "bg-warning";
          case "alfa":
            return "bg-danger";
          case "belum_absen":
            return "bg-secondary";
          case "izin":
            return "bg-info";
          default:
            return "bg-secondary";
        }
    }

    public function fetchJadwalData($ruangId)
    {
        // Generic query, can be overridden by child classes
        $query = "SELECT tbl_jadwal.*, tbl_hari.nama_hari, tbl_matpel.nama_matpel, tbl_guru.nama_guru, tbl_kelas.nama_kelas, tbl_absensi.nama_absensi FROM tbl_jadwal INNER JOIN tbl_hari ON tbl_jadwal.id_hari = tbl_hari.id INNER JOIN tbl_matpel ON tbl_jadwal.id_mata_pelajaran = tbl_matpel.id INNER JOIN tbl_guru ON tbl_jadwal.id_guru = tbl_guru.id INNER JOIN tbl_kelas ON tbl_jadwal.id_kelas = tbl_kelas.id INNER JOIN tbl_absensi ON tbl_jadwal.id_absensi = tbl_absensi.id WHERE tbl_jadwal.id_ruang = {$ruangId} ORDER BY tbl_hari.id, tbl_jadwal.jam;";

        $result = mysqli_query($this->koneksi, $query);
        $jadwalData = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $jadwalData;
    }
}

class TKJ1 extends Jadwal
{
    public function __construct($koneksi)
    {
        parent::__construct($koneksi);
    }

    public function fetchJadwalData($ruangId)
    {
        // Custom query for TKJ1
        $query = "SELECT tbl_jadwal.*, tbl_hari.nama_hari, tbl_matpel.nama_matpel, tbl_guru.nama_guru, tbl_kelas.nama_kelas, tbl_absensi.nama_absensi FROM tbl_jadwal INNER JOIN tbl_hari ON tbl_jadwal.id_hari = tbl_hari.id INNER JOIN tbl_matpel ON tbl_jadwal.id_mata_pelajaran = tbl_matpel.id INNER JOIN tbl_guru ON tbl_jadwal.id_guru = tbl_guru.id INNER JOIN tbl_kelas ON tbl_jadwal.id_kelas = tbl_kelas.id INNER JOIN tbl_absensi ON tbl_jadwal.id_absensi = tbl_absensi.id WHERE tbl_jadwal.id_ruang = 1 ORDER BY tbl_hari.id, tbl_jadwal.jam;";

        $result = mysqli_query($this->koneksi, $query);
        $jadwalData = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $jadwalData;
    }

  }

class TKJ2 extends Jadwal
{
    public function __construct($koneksi)
    {
        parent::__construct($koneksi);
    }

    public function fetchJadwalData($ruangId)
    {
        // Custom query for TKJ1
        $query = "SELECT tbl_jadwal.*, tbl_hari.nama_hari, tbl_matpel.nama_matpel, tbl_guru.nama_guru, tbl_kelas.nama_kelas, tbl_absensi.nama_absensi FROM tbl_jadwal INNER JOIN tbl_hari ON tbl_jadwal.id_hari = tbl_hari.id INNER JOIN tbl_matpel ON tbl_jadwal.id_mata_pelajaran = tbl_matpel.id INNER JOIN tbl_guru ON tbl_jadwal.id_guru = tbl_guru.id INNER JOIN tbl_kelas ON tbl_jadwal.id_kelas = tbl_kelas.id INNER JOIN tbl_absensi ON tbl_jadwal.id_absensi = tbl_absensi.id WHERE tbl_jadwal.id_ruang = 2  ORDER BY tbl_hari.id, tbl_jadwal.jam;";

        $result = mysqli_query($this->koneksi, $query);
        $jadwalData = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $jadwalData;
    }

}
class TKJ3 extends Jadwal
{
    public function __construct($koneksi)
    {
        parent::__construct($koneksi);
    }

    public function fetchJadwalData($ruangId)
    {
        // Custom query for TKJ1
        $query = "SELECT tbl_jadwal.*, tbl_hari.nama_hari, tbl_matpel.nama_matpel, tbl_guru.nama_guru, tbl_kelas.nama_kelas, tbl_absensi.nama_absensi FROM tbl_jadwal INNER JOIN tbl_hari ON tbl_jadwal.id_hari = tbl_hari.id INNER JOIN tbl_matpel ON tbl_jadwal.id_mata_pelajaran = tbl_matpel.id INNER JOIN tbl_guru ON tbl_jadwal.id_guru = tbl_guru.id INNER JOIN tbl_kelas ON tbl_jadwal.id_kelas = tbl_kelas.id INNER JOIN tbl_absensi ON tbl_jadwal.id_absensi = tbl_absensi.id WHERE tbl_jadwal.id_ruang = 3  ORDER BY tbl_hari.id, tbl_jadwal.jam;";

        $result = mysqli_query($this->koneksi, $query);
        $jadwalData = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $jadwalData;
    }

}
class TKJ4 extends Jadwal
{
    public function __construct($koneksi)
    {
        parent::__construct($koneksi);
    }

    public function fetchJadwalData($ruangId)
    {
        // Custom query for TKJ1
        $query = "SELECT tbl_jadwal.*, tbl_hari.nama_hari, tbl_matpel.nama_matpel, tbl_guru.nama_guru, tbl_kelas.nama_kelas, tbl_absensi.nama_absensi FROM tbl_jadwal INNER JOIN tbl_hari ON tbl_jadwal.id_hari = tbl_hari.id INNER JOIN tbl_matpel ON tbl_jadwal.id_mata_pelajaran = tbl_matpel.id INNER JOIN tbl_guru ON tbl_jadwal.id_guru = tbl_guru.id INNER JOIN tbl_kelas ON tbl_jadwal.id_kelas = tbl_kelas.id INNER JOIN tbl_absensi ON tbl_jadwal.id_absensi = tbl_absensi.id WHERE tbl_jadwal.id_ruang = 3  ORDER BY tbl_hari.id, tbl_jadwal.jam;";

        $result = mysqli_query($this->koneksi, $query);
        $jadwalData = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $jadwalData;
    }

}

