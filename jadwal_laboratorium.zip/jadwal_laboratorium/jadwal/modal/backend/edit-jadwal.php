<?php
require_once "../../../config.php";

error_reporting(E_ALL);
ini_set('display_errors', '1');

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $nama_hari = $_POST['id_hari'];
    $nama_matpel = $_POST['id_mata_pelajaran'];
    $nama_guru = $_POST['id_guru'];
    $jam = $_POST['jam'];
    $id_ruang = $_POST['id_ruang'];
    $nama_kelas = $_POST['id_kelas'];

    // Extract only the hour part from the submitted time
    $hourPart = date('H', strtotime($jam));

    // Check if there is any existing schedule at the same hour, day, but different room
    $checkQuery = "SELECT COUNT(*) as count FROM tbl_jadwal WHERE HOUR(jam) = '$hourPart' AND id_hari = '$nama_hari' AND id_ruang = '$id_ruang'";
  $checkResult = mysqli_query($koneksi, $checkQuery);

  if (!$checkResult) {
    die("Query failed: " . mysqli_error($koneksi));
  }

  $row = mysqli_fetch_assoc($checkResult);
  $count = $row['count'];

    // If there is an existing schedule, prevent the update
    if ($count > 0) {
        echo '<script>';
        echo 'alert("Jadwal pada jam dan hari tersebut sudah ada di jadwal lain. Silakan pilih jam atau hari lain.");';
        echo 'window.location.href = "' . BASE_URL . '/jadwal/jadwal.php";';
        echo '</script>';
        exit; // Stop execution to prevent further processing
    }

    // Use proper SQL syntax for UPDATE query
    $query = "UPDATE tbl_jadwal SET
     id_hari = '$nama_hari',
     id_mata_pelajaran = '$nama_matpel',
     id_guru = '$nama_guru',
     jam = '$jam',
     id_kelas = '$nama_kelas'
    WHERE id_jadwal = '$id'";

    // Eksekusi query
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        die("Query failed: " . mysqli_error($koneksi));
    }

    // Redirect ke halaman index
    echo '<script>';
    echo 'alert("Data berhasil di edit");';
    echo 'window.location.href = "' . BASE_URL . '/jadwal/jadwal.php";';
    echo '</script>';
}
