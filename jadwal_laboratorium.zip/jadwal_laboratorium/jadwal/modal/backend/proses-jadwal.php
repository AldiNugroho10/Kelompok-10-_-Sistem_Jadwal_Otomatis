<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ../auth/login.php");
  exit;
}

require_once "../../../config.php";

if (isset($_POST['submit'])) {
  $nama_hari = $_POST['id_hari'];
  $nama_matpel = $_POST['id_mata_pelajaran'];
  $nama_guru = $_POST['id_guru'];
  $jam = $_POST['jam'];
  $nama_kelas = $_POST['id_kelas'];
  $status = isset($_POST['id_absensi']); // Fix for undefined array key
  $id_ruang = $_POST['id_ruang'];

  // Cek apakah nama hari, mata pelajaran, guru, dan kelas sudah diisi
  if (empty($nama_hari) || empty($nama_matpel) || empty($nama_guru) || empty($nama_kelas)) {
    echo "Maaf, semua data harus diisi";
    exit;
  }

  // Escape data untuk mencegah SQL injection
  $nama_hari = mysqli_real_escape_string($koneksi, $nama_hari);
  $nama_matpel = mysqli_real_escape_string($koneksi, $nama_matpel);
  $nama_guru = mysqli_real_escape_string($koneksi, $nama_guru);
  $nama_kelas = mysqli_real_escape_string($koneksi, $nama_kelas);

  // Extract only the hour part from the submitted time
  $hourPart = date('H', strtotime($jam));

  // Check if there is any existing schedule at the same hour, day, and room
  $checkQuery = "SELECT COUNT(*) as count FROM tbl_jadwal WHERE HOUR(jam) = '$hourPart' AND id_hari = '$nama_hari' AND id_ruang = '$id_ruang'";
  $checkResult = mysqli_query($koneksi, $checkQuery);

  if (!$checkResult) {
    die("Query failed: " . mysqli_error($koneksi));
  }

  $row = mysqli_fetch_assoc($checkResult);
  $count = $row['count'];

  // If there is an existing schedule, prevent the insertion
  if ($count > 0) {
    echo '<script>';
    echo 'alert("Jadwal pada jam, hari, dan ruang tersebut sudah ada. Silakan pilih jam, hari, atau ruang lain.");';
    echo "window.location.href = '" . BASE_URL . "jadwal/jadwal.php';";
    echo '</script>';
    exit; // Stop execution to prevent further processing
  }


  // Buat query insert data
  $query = "INSERT INTO tbl_jadwal (`id_hari`, `id_mata_pelajaran`, `id_guru`, `id_kelas`, `jam`, `tanggal`, `id_absensi`, `id_ruang`) VALUES ('$nama_hari', '$nama_matpel', '$nama_guru', '$nama_kelas', '$jam', NOW(), '5', '$id_ruang');";

  // Eksekusi query
  $result = mysqli_query($koneksi, $query);

  // Cek apakah query berhasil dieksekusi
  if ($result) {
    // Redirect ke halaman kelas
    echo '<script>';
    echo 'alert("Jadwal Berhasil Ditambahkan");';
    echo "window.location.href = '" . BASE_URL . "jadwal/jadwal.php';";
    echo '</script>';
  } else {
    // Tampilkan error
    echo '<script>';
    echo 'alert("Error: ' . mysqli_error($koneksi) . '");';
    echo "window.location.href = '" . BASE_URL . "jadwal/jadwal.php';";
    echo '</script>';
  }
}
