<div class="modal fade" id="ModalAdd" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?= BASE_URL; ?>/jadwal/modal/backend/proses-jadwal.php" method="post" enctype="multipart/form-data">
        <!-- <input type="text" name="id" value="<?= $data['id_jadwal'] ?>"> -->

        <div class="modal-header">
          <h5 class="modal-title fs-5" id="exampleModalLabel">Tambah Data Jadwal</h5>
          <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body" style="background-color: #f9f9f9;">
          <div class="mb-2">
            <label for="nama_hari" class="form-label">Hari:</label>
            <select class="form-select" name="id_hari" id="id_hari">
              <option value="nama_hari" selected>--Pilih Hari--</option>
              <?php
              $sql = "SELECT * FROM tbl_hari";
              $query = mysqli_query($koneksi, $sql);
              while ($data = mysqli_fetch_array($query)) {
                echo '<option value="' . $data['id'] . '">' . $data['nama_hari'] . '</option>';
              }
              ?>
            </select>
          </div>

          <div class="mb-2">
            <label for="nama_matpel" class="form-label">Mata Pelajaran:</label>
            <select class="form-select" name="id_mata_pelajaran" id="id_mata_pelajaran">
              <option value="nama_matpel" selected>--Pilih Mata Pelajaran--</option>
              <?php
              $sql = "SELECT * FROM tbl_matpel";
              $query = mysqli_query($koneksi, $sql);
              while ($data = mysqli_fetch_array($query)) {
                echo '<option value="' . $data['id'] . '">' . $data['nama_matpel'] . '</option>';
              } ?>
            </select>
          </div>

          <div class="mb-2">
            <label for="nama_guru" class="form-label">Guru:</label>
            <select class="form-select" name="id_guru" id="id_guru">
              <option value="nama_guru" selected>--Pilih Guru--</option>
              <?php
              $sql = "SELECT * FROM tbl_guru";
              $query = mysqli_query($koneksi, $sql);
              while ($data = mysqli_fetch_array($query)) {
                echo '<option value="' . $data['id'] . '">' . $data['nama_guru'] . '</option>';
              } ?>
            </select>
          </div>

          <div class="mb-2">
            <label for="jam" class="form-label">Jam:</label>
            <input class="form-control" type="time" name="jam" id="jam" required step="60">
          </div>

          <input type="hidden" name="id_absensi" id="id_absensi" value="belum_absen">

          <div class="mb-2">
            <label for="nama_kelas" class="form-label">Kelas:</label>
            <select class="form-select" name="id_kelas" id="id_kelas">
              <option value="nama_kelas" selected>--Pilih Kelas--</option>
              <?php
              $sql = "SELECT * FROM tbl_kelas";
              $query = mysqli_query($koneksi, $sql);
              while ($data = mysqli_fetch_array($query)) {
                echo '<option value="' . $data['id'] . '">' . $data['nama_kelas'] . '</option>';
              } ?>
            </select>
          </div>

          <div class="mb-2">
            <label for="ruang" class="form-label">Ruang:</label>
            <select class="form-select" name="id_ruang" id="id_ruang">
              <option value="nama_ruang" selected>--Pilih Ruang--</option>
              <?php
              $sql = "SELECT * FROM tbl_ruang";
              $query = mysqli_query($koneksi, $sql);
              while ($data = mysqli_fetch_array($query)) {
                echo '<option value="' . $data['id_ruang'] . '">' . $data['nama_ruang'] . '</option>';
              } ?>
            </select>
          </div>


        </div>


        <div class="modal-footer" style="background-color: #f9f9f9;">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
          <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>