<div class="modal fade" id="ModalEdit<?= $no ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?= BASE_URL; ?>/jadwal/modal/backend/edit-jadwal.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $data['id_jadwal'] ?>">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Data </h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-2">
            <label for="id_hari" class="form-label">Hari:</label>
            <select class="form-select" name="id_hari" id="id_hari">
              <?php
              $sqlHari = "SELECT * FROM tbl_hari";
              $queryHari = mysqli_query($koneksi, $sqlHari);
              while ($dataHari = mysqli_fetch_array($queryHari)) { ?>
                <option value="<?= $dataHari['id'] ?>" <?= $data['id_hari'] == $dataHari['id'] ? 'selected' : '' ?>>
                  <?= $dataHari['nama_hari'] ?>
                </option>
              <?php }
              ?>
            </select>
          </div>


          <div class="mb-2">
            <label for="id_mata_pelajaran" class="form-label">Matpel:</label>
            <select class="form-select" name="id_mata_pelajaran" id="id_mata_pelajaran">
              <?php
              $sqlHari = "SELECT * FROM tbl_matpel";
              $queryHari = mysqli_query($koneksi, $sqlHari);
              while ($dataHari = mysqli_fetch_array($queryHari)) { ?>
                <option value="<?= $dataHari['id'] ?>" <?= $data['id_mata_pelajaran'] == $dataHari['id'] ? 'selected' : '' ?>><?= $dataHari['nama_matpel'] ?></option>
              <?php }
              ?>
            </select>
          </div>
          <div class="mb-2">
            <label for="id_guru" class="form-label">Guru:</label>
            <select class="form-select" name="id_guru" id="id_guru">
              <?php
              $sqlHari = "SELECT * FROM tbl_guru";
              $queryHari = mysqli_query($koneksi, $sqlHari);
              while ($dataHari = mysqli_fetch_array($queryHari)) { ?>
                <option value="<?= $dataHari['id'] ?>" <?= $data['id_guru'] == $dataHari['id'] ? 'selected' : '' ?>><?= $dataHari['nama_guru'] ?></option>
              <?php }
              ?>
            </select>
          </div>

          <div class="mb-2">
            <label for="jam" class="form-label">Jam:</label>
            <input type="time" class="form-control" name="jam" id="jam" value="<?= date('H:i', strtotime($data["jam"])); ?>">
          </div>

          <div>
            <label for="id_kelas" class="form-label">Kelas:</label>
            <select class="form-select" name="id_kelas" id="id_kelas">
              <?php
              $sqlHari = "SELECT * FROM tbl_kelas";
              $queryHari = mysqli_query($koneksi, $sqlHari);
              while ($dataHari = mysqli_fetch_array($queryHari)) { ?>
                <option value="<?= $dataHari['id'] ?>" <?= $data['id_kelas'] == $dataHari['id'] ? 'selected' : '' ?>><?= $dataHari['nama_kelas'] ?></option>
              <?php }
              ?>
            </select>
          </div>
          <input type="hidden" name="id_ruang" value="<?= $data['id_ruang'] ?>">
          <?php if ($_SESSION['level'] == "guru") { ?>
            <div class="mb-2">
              <label for="id_absensi" class="form-label">Status:</label>
              <select class="form-select" name="id_absensi" id="id_absensi">
                <?php
                $sqlHari = "SELECT * FROM tbl_absensi";
                $queryHari = mysqli_query($koneksi, $sqlHari);
                while ($dataHari = mysqli_fetch_array($queryHari)) { ?>
                  <option value="<?= $dataHari['id'] ?>" <?= $data['id_absensi'] == $dataHari['id'] ? 'selected' : '' ?>><?= $dataHari['status'] ?></option>
                <?php }
                ?>
              <?php }
              ?>
              </select>
            </div>





            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
      </form>
    </div>
  </div>
</div>