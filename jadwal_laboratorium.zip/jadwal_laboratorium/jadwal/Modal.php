<?php 
include __DIR__."/modal/modal-dltd.php";
include __DIR__."/modal/modal-edit.php";
?>