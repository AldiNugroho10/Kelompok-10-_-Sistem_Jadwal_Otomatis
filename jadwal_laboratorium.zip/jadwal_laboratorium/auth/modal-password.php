<!-- HTML -->
<div class="modal fade" id="modalPassword" tabindex="-1" aria-labelledby="ModalAdd" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?= BASE_URL ?>auth/p-lupas.php" method="post">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title fs-5" id="exampleModalLabel">Lupa Password</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" style="background-color: #f9f9f9;">
          <div class="mb-3">
            <label for="email" class="form-label">Masukkan Email atau nama pengguna:</label>
            <input class="form-control" type="text" name="email" id="email" required>
          </div>
          <div class="d-flex justify-content-end"><button type="button" id="btnCariEmail" class="btn btn-primary" onclick="cariEmail()">
              Cari Email
            </button>
          </div>

          <!-- <div id="hasilEmail" class="mt-3"></div> -->

          <div id="formPassword" style="display: none;">
            <div class="mb-3">
              <label for="password" class="form-label">Password Baru:</label>
              <input class="form-control" type="password" name="password" id="password" required>
            </div>
            <div class="mb-3">
              <label for="re_password" class="form-label">Konfirmasi Password Baru:</label>
              <input class="form-control" type="password" name="re_password" id="re_password" required>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="background-color: #f9f9f9;">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
          <button type="submit" name="submit_password" class="btn btn-primary" id="tombolSubmit" style="display: none;">
            <i class="bi bi-check-circle"></i> Simpan
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  // JavaScript
  document.addEventListener("DOMContentLoaded", function() {
    document.getElementById('btnCariEmail').addEventListener('click', cariEmail);

    function cariEmail() {
      var email = document.getElementById('email').value;

      // Check if the email is empty
      if (!email) {
        alert('Masukan Email Anda');
        return;
      }

      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
          var response = JSON.parse(xhr.responseText);
          handleResponse(response);
        }
      };

      xhr.open('POST', 'cek_email.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.send('email=' + email);
    }


    function handleResponse(response) {
      var divHasilEmail = document.getElementById('hasilEmail');
      var divFormPassword = document.getElementById('formPassword');
      var tombolSubmit = document.getElementById('tombolSubmit');

      if (response.emailAda) {
        // console.log("EmailAda")
        alert('Email ditemukan. Silakan lanjutkan.');
        divFormPassword.style.display = 'block';
        tombolSubmit.style.display = 'block';
      } else {
        // console.log("Kosong MEK")
        alert('Email tidak ditemukan. Harap periksa input Anda.');
        return;
        divFormPassword.style.display = 'none';
        tombolSubmit.style.display = 'none';
      }
    }
  });
</script>