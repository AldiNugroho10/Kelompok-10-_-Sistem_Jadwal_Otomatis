<?php
// Hubungkan ke database
require_once "../config.php";

// Fungsi untuk mencari user berdasarkan email atau username
function setEmailUsername($data)
{
    $query = "SELECT * FROM tbl_user WHERE email = '$data' OR username = '$data'";
    $result = mysqli_query($GLOBALS['koneksi'], $query);
    return mysqli_fetch_assoc($result);
}

// Fungsi untuk mengubah password user
function forgot_password($key, $data)
{
    $query = "UPDATE tbl_user SET password = '$data' WHERE id_user = '$key'";
    $result = mysqli_query($GLOBALS['koneksi'], $query);
    return $result;
}

// Bagian utama
if (isset($_POST['submit_email'])) {
    $email = $_POST['email'];

    // Validasi input
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Email tidak valid.'); window.location.href='../';</script>";
        exit();
    }

    // Cari user
    $user = setEmailUsername($email);

    // Jika user ditemukan, tampilkan formulir penggantian password
    if ($user) {
        // Tidak perlu redirect, script akan menangani tampilan modal
    } else {
        echo "<script>alert('User tidak ditemukan.'); window.location.href='../';</script>";
        exit();
    }
}

// Proses penggantian password
if (isset($_POST['submit_password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $re_password = $_POST['re_password'];

    // Validasi input
    if (strlen($password) < 4) {
        echo "<script>alert('Password minimal 4 karakter.'); window.location.href='../';</script>";
        exit();
    }

    if ($password !== $re_password) {
        echo "<script>alert('Password tidak sama.'); window.location.href='../';</script>";
        exit();
    }

    // Enkripsi password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Cari user
    $user = setEmailUsername($email);

    // Jika user ditemukan, ubah password
    if ($user) {
        // Enkripsi password lagi untuk menghindari SQL injection
        $password_hash = mysqli_real_escape_string($GLOBALS['koneksi'], $password_hash);
        $result = forgot_password($user['id_user'], $password_hash);

        if ($result) {
            echo "<script>alert('Password berhasil diubah silahkan login.'); window.location.href='../';</script>";
            exit();
        } else {
            echo "<script>alert('Gagal mengubah password.'); window.location.href='../';</script>";
            exit();
        }
    } else {
        echo "<script>alert('User tidak ditemukan.'); window.location.href='../';</script>";
        exit();
    }
}
    $email = $_POST['email'];

    // Mengecek keberadaan email di tabel tbl_user
    $query = "SELECT COUNT(*) as total FROM tbl_user WHERE email = '$email'";
    $result = $koneksi->query($query);
    $row = $result->fetch_assoc();

    // Mengirim respons ke JavaScript dengan menggunakan JSON
    $response = array('emailAda' => ($row['total'] > 0));
    echo json_encode($response);

    // Menutup koneksi ke database
    $koneksi->close();

