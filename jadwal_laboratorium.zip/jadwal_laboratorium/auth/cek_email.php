<?php
// cek_email.php

require_once '../config.php';

// Mendapatkan nilai email dari permintaan POST
$email = $_POST['email'];

// Koneksi ke database


// Mengecek keberadaan email di tabel tbl_user
$query = "SELECT COUNT(*) as total FROM tbl_user WHERE email = ?";
$stmt = $koneksi->prepare($query);
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->bind_result($total);
$stmt->fetch();
$stmt->close();

// Mengirim respons ke JavaScript dengan menggunakan JSON
$response = array('emailAda' => ($total > 0));
echo json_encode($response);

// Menutup koneksi ke database
$koneksi->close();
?>
