<?php

session_start();

if (isset($_SESSION['sslogin'])) {
    header("Location: ../index.php");
    exit;
}


require_once "../config.php";

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Login - SMKN 1 RAWAMERTA</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/styles.css">
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <link rel="icon" type="image/x-icon" href="<?= BASE_URL ?>assets/image/logo.png">
    <link rel="stylesheet" href="style.css">
</head>

<body class="bg-primary" id="bg-login">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-5">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <center>
                                        
                                        <img src="../assets/image/logo.png" alt="Image" class="logo" align="center" style="width:125px ;">
                                    </center>
                                    <h4 class="text-center font -weight-light my-3">Login - SMKN 1 RAWAMERTA</h4>
                                </div>
                                <div class="card-body">
                                    <form action="proseslogin.php" method="POST">
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="username" name="username" type="text" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{3,}$" title="kombinasi angka dan huruf minimal 3 karakter" placeholder="username" autocomplete="off" required />
                                            <label for="username">Username</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputPassword" type="password" placeholder="Password" name="password" required />
                                            <label for="inputPassword">Password</label>
                                        </div>
                                        <a href="#modalPassword" class="text-muted small rounded-pill" data-bs-toggle="modal" data-bs-target="#modalPassword">Lupa Password?</a>
                                        <button type="submit" name="login" class="btn btn-primary col-12 rounded-pill my-2">Login</button>
                                    </form>
                                    <?php include_once __DIR__ . "/modal-password.php"; ?>
                                </div>
                                <div class="card-footer text-center py-3">
                                    <div class="text-muted small">Copyright &copy; SMKN 1 RAWAMERTA <?= date("Y"); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="<?= BASE_URL; ?>assets/js/datatables-simple-demo.js"></script>
</body>

</html>