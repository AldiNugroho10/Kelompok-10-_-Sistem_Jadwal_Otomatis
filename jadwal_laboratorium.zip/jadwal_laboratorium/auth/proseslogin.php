<?php

session_start();
require_once __DIR__ . '../../config.php';
// fllw

class User
{
    private $koneksi;

    public function __construct($koneksi)
    {
        $this->koneksi = $koneksi;
    }
//BENER KAN? OKEE// OPSOO
    public function getByUsername($username)
    {
        $result = mysqli_query($this->koneksi, "SELECT * FROM tbl_user WHERE username = '$username'");
        return mysqli_fetch_assoc($result);
    }
}

class LoginManager
{
    private $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function login($username, $password)
    {
        $userData = $this->user->getByUsername($username);

        if ($userData && password_verify($password, $userData['password'])) {
            $_SESSION['sslogin'] = true;
            $_SESSION['ssUser'] = $username;
            $_SESSION['level'] = $userData['level'];
            header("Location: ../index.php");
            exit;
        } else {
            $this->showError("Username atau Password Salah");
        }
    }

    private function showError($message)
    {
        echo "<script>
            alert('$message');
            document.location.href = 'login.php';
        </script>";
    }
}

// Usage
if (isset($_POST['login'])) {
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);

    $koneksi = new mysqli('localhost', 'root', '', 'backend');
    
    $user = new User($koneksi);
    $loginManager = new LoginManager($user);
    
    $loginManager->login($username, $password);
}
?>