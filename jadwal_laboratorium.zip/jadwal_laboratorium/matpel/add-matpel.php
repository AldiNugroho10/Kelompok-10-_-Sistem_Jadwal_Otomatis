<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ../auth/login.php");
  exit;
}


require_once "../config.php";

$title = "Tambah Mata Pelajaran - SMKN 1 RAWAMERTA";
require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";

?>

<div id="layoutSidenav_content">
  <main class="container mt-4">
    <h1 class=" mb-4">Tambah Mata Pelajaran</h1>
    <ol class="breadcrumb mb-4">
      <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
      <li class="breadcrumb-item active"><a href="matpel.php">Mata Pelajaran</a></li>
      <li class="breadcrumb-item">Tambah Mata Pelajaran</li>
    </ol>
    <form action="./backend/proses-matpel.php" method="POST">
      <div class="card">
        <div class="card-header align-items-center">
          <span class="h5 mx-2"><i class="fa-solid fa-square-plus me-2"> </i>Tambah Matpel</span>
          <button type="submit" name="simpan" class="btn btn-primary float-end">Simpan <i class="fa-solid fa-floppy-disk mx-1"></i></button>
          <button type="reset" name="reset" class="btn btn-danger float-end me-2">Reset <i class="fa-solid fa-xmark mx-1"></i></button>
        </div>
        <div class="card-body">
          <div class="row mb-3">
            <label for="kode_matpel" class="col-sm-2 col-form-label">Kode Matpel</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <input type="text" class="form-control border-0 border-bottom" id="kode_matpel" name="kode_matpel" autocomplete="off">
            </div>
          </div>
          <div class="row mb-3">
            <label for="nama_matpel" class="col-sm-2 col-form-label">Nama Matpel</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <input type="text" class="form-control border-0 border-bottom" id="nama_matpel" name="nama_matpel" autocomplete="off">
            </div>
          </div>
        </div>
      </div>
    </form>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>
<?php

require_once "../templates/footer.php";


?>