<?php 
include __DIR__."/modal/modal_dltd.php";
include __DIR__."/modal/modal_edit.php";

?>