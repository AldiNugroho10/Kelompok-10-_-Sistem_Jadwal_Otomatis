<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
	header("Location: ./auth/login.php");
	exit;
}

require_once "../../config.php";

if (isset($_POST['submit'])) {
	$id = $_POST['id_matpel'];

	$result = mysqli_query($koneksi, "DELETE FROM tbl_matpel WHERE id = $id");

	if ($result) {
		$_SESSION['succses'] = '';
	} else {
		$_SESSION['failed'] = '';
	}
	header('location: ../matpel.php');
}
