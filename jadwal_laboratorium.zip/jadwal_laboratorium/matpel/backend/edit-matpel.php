<?php

session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./auth/login.php");
  exit;
}

require_once "../../config.php";

if (isset($_POST['submit'])) {
  $id = $_POST['id_matpel'];
  $kd = htmlspecialchars($_POST['kode_matpel']);
  $matpel = htmlspecialchars($_POST['nama_matpel']);

  $query = "UPDATE tbl_matpel SET 
      kode_matpel = '$kd',
      nama_matpel = '$matpel'

  WHERE id = $id";

  // Memperbarui data di database
  mysqli_query($koneksi, $query);

  $_SESSION['edit'] = 'data berhasil di edit';
  header('location: ../matpel.php');
}


require_once "../../templates/footer.php";
