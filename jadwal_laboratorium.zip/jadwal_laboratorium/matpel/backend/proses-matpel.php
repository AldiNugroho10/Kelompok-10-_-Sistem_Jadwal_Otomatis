<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ../auth/login.php");
  exit;
}

require_once "../../config.php";

if (isset($_POST['simpan'])) {
  $km = trim(htmlspecialchars($_POST['kode_matpel']));
  $nm = trim(htmlspecialchars($_POST['nama_matpel']));
  // Lakukan validasi data jika diperlukan

  // Format query dengan benar
  $query = "INSERT INTO tbl_matpel (kode_matpel, nama_matpel) VALUES ('$km', '$nm')";

  // Eksekusi query
  $result = mysqli_query($koneksi, $query);

  if ($result) {
    echo "<script>
                  alert('Data Berhasil di Simpan');
              </script>";
    header('location: ../matpel.php');
  } else {
    echo "Error: " . mysqli_error($koneksi);
    header("Location : ../add-matpel.php");
  }
}

