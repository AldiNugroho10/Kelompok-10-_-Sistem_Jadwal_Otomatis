<?php
session_start();
require_once "../config.php";


if (!isset($_SESSION['sslogin'])) {
  echo "<script>
  alert('Anda Belum Login');
  document.location.href = 'password.php';
  </script>";
  exit;
}
  // Periksa apakah tombol "simpan" ditekan
if (isset($_POST['simpan'])) {
  $username = trim(htmlspecialchars($_POST['username']));
  $nama = trim(htmlspecialchars($_POST['nama']));
  $alamat = trim(htmlspecialchars($_POST['alamat']));
  $email = trim(htmlspecialchars($_POST['email']));
  $nrp = trim(htmlspecialchars($_POST['nrp']));
  $password = trim(htmlspecialchars($_POST['password']));
  $level = trim(htmlspecialchars($_POST['level'])); // Get the selected level value

  $pass = password_hash($password, PASSWORD_DEFAULT);

  $cekUsername = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username = '$username'");
  if (mysqli_num_rows($cekUsername) > 0) {
    header("Location: ../user/add-user.php?msg=cancel");
    exit();
  } else {
    $insertUserQuery = "INSERT INTO tbl_user (username, nama, alamat, password, level, email, nrp)
                        VALUES ('$username', '$nama', '$alamat', '$pass', '$level', '$email', '$nrp')";

    if (mysqli_query($koneksi, $insertUserQuery)) {
      header("Location: ../user/add-user.php?msg=added");
    } else {
      // Error inserting user, handle the error as needed
      echo "Error: " . mysqli_error($koneksi);
    }
  }
}
