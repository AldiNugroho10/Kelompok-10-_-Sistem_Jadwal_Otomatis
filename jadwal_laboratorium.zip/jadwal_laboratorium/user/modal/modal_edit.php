<?php
$levels = ['kepala-lab', 'kepsek', 'guru'];

?>


<div class="modal fade" id="ModalEdit<?= $no ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="./backend/edit-user.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id_user" value="<?= $data['id_user'] ?>">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Data </h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <div class="mb-2">
            <label for="username" class="form-label">username :</label>
            <input class="form-control" type="text" name="username" id="username" value="<?= $data['username']; ?>" required>
          </div>
          <div class="mb-2">
            <label for="alamat" class="form-label">Alamat :</label>
            <input class="form-control" type="text" name="alamat" id="alamat" value="<?= $data['alamat']; ?>">
          </div>
          <div class="mb-4">
            <label for="email" class="form-label">Email :</label>
            <input class="form-control" type="text" name="email" id="email" value="<?= $data['email']; ?>">
          </div>
          <!-- <div class="mb-2">
            <label for="level" class="form-label">Jabatan :</label>
            <select class="form-select" name="level" id="level" readonly>
              <option value="" selected>Pilih Jabatan</option>
              <?php foreach ($levels as $level) : ?>
                <option value="<?= $level ?>" <?= $level == $data['level'] ? 'selected' : '' ?>><?= $level ?></option readonly>
              <?php endforeach; ?>
            </select>
          </div> -->
          <div clas="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
          </div>
      </form>
    </div>
  </div>
</div>