<?php
session_start();

if (!isset($_SESSION['sslogin']) || ($_SESSION['level'] != "kepala-lab")) {
  echo "<script>
                  alert('Anda Bukan Admin');
              </script>";
  header("Location: ../auth/login.php");
  exit;
}


require_once "../config.php";

$title = "Tambah User - SMKN 1 RAWAMERTA";
require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";

if (isset($_GET['msg'])) {
  $msg = $_GET['msg'];
} else {
  $msg = "";
}

$alert = "";
if ($msg == "cancel") {
  $alert = '<div class="alert alert-warning alert-dismissible fade show" role="alert"><i class="ri-error-warning-line"></i>
    <strong>Gagal!</strong> Username Telah Terdaftar
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}

if ($msg == "added") {
  $alert = '<div class="alert alert-success alert-dismissible fade show" role="alert"><i class="fa-solid fa-circle-check"></i>
    <strong>Berhasil!</strong> Tambah User Berhasil, Password : 1234 silahkan login
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}
?>

<div id="layoutSidenav_content">
  <main class="container mt-2">
    <h1 class=" mb-2">Tambah User</h1>
    <ol class="breadcrumb mb-4">
      <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
      <li class="breadcrumb-item"><a href="user.php">Data User</a></li>
      <li class="breadcrumb-item active">Tambah User</li>
    </ol>
    <form action="proses-user.php" method="POST">
      <input type="hidden" name="password" value="1234">
      <?php
      if ($msg != "") {
        echo $alert;
      }

      ?>
      <div class="card">
        <div class="card-header align-items-center">
          <span class="h5 mx-2">Tambah User <i class="fa-solid fa-square-plus"> </i></span>
          <button type="submit" name="simpan" class="btn btn-primary float-end">Simpan <i class="fa-solid fa-floppy-disk mx-1"></i></button>
          <button type="reset" name="reset" class="btn btn-danger float-end me-2">Reset <i class="fa-solid fa-xmark mx-1"></i></button>
        </div>
        <div class="card-body">
          <div class="row mb-3">
            <label for="username" class="col-sm-2 col-form-label">Username</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <input type="text" pattern="[a-zA-Z0-9]{3,}" title="Minimal 3 Karakter kombinasi huruf besar huruf kecil dan angka" class="form-control border-0 border-bottom" id="username" name="username" maxlength="20" autocomplete="off" required>
            </div>
          </div>
          <div class="row mb-3">
            <label for="nama" class="col-sm-2 col-form-label">Nama Lengkap</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <input type="text" class="form-control border-0 border-bottom" id="nama" name="nama" maxlength="20" autocomplete="off" required>
            </div>
          </div>
          <div class="row mb-3">
            <label for="nrp" class="col-sm-2 col-form-label">NIP</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <input type="number" class="form-control border-0 border-bottom" id="nrp" name="nrp" autocomplete="off" required>
            </div>
          </div>
          <div class="row mb-3">
            <label for="email" class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <input type="email" class="form-control border-0 border-bottom" id="email" name="email" autocomplete="off" required>
            </div>
          </div>
          <div class="row mb-3">
            <label for="alamat" class="col-sm-2 col-form-label" autocomplete="off" required>Alamat</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <textarea class="form-control border-0 border-bottom" id="alamat" name="alamat" rows="3"></textarea>
            </div>
          </div>
          <div class="row mb-3">
            <label for="level" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <select name="level" id="level" class="form-select border-0 border-bottom">
                <option value="level" selected>--Pilih Jabatan</option>
                <option value="kepsek">Kepsek</option>
                <option value="kepala-lab">Kepala-Lab</option>
                <option value="guru">Guru Mata Pelajaran</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </form>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>
<?php

require_once "../templates/footer.php";


?>