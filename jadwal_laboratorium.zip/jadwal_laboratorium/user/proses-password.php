<?php 

session_start();


if (!isset($_SESSION['sslogin'])) {
  echo "<script>
  alert('Anda Belum Login');
  document.location.href = 'password.php';
  </script>";
  exit;
}

require_once "../config.php";

if (isset($_POST['simpan'])) {
  $curPass = trim(htmlspecialchars($_POST['curPass']));
  $newPass = trim(htmlspecialchars($_POST['newPass']));
  $confPass = trim(htmlspecialchars($_POST['confPass']));
  echo "
  <script>
  console.log('Password lama : $_SESSION[ssUser]');
  </script>
  ";

  $userName = $_SESSION['ssUser'];
  $queryUser = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username = '$userName'");
  $data = mysqli_fetch_array($queryUser);

  if ($newPass !== $confPass) {
    // header('location:password.php?msg=err1');]
    $ppp = $data["password"];
    echo '<script>
      alert("'.$ppp.'");
      document.location.href = "password.php";
      </script>';
  } 

  if (!password_verify($curPass, $data['password'])) {
    // header('Location:password.php?msg=err2');
    echo "<script>
      alert('Password lama tidak sesuai');
      document.location.href = 'password.php';
      </script>";
    // exit;
  }else {
    $pass = password_hash($newPass, PASSWORD_DEFAULT);;
    mysqli_query($koneksi, "UPDATE tbl_user SET password = '$pass' WHERE username = '$userName'");
    // header('location:password.php?msg=updated');
    echo "<script>
      alert('Password Berhasil di ubah');
      document.location.href = 'password.php';
      </script>";
    // exit;
  }
}
