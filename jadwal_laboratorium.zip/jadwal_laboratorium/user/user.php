<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./auth/login.php");
  exit;
}

require_once "../config.php";

$title = "Daftar User";

require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";

?>


<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid px-4">
      <h1 class="mt-2">Data User</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Data User</li>
      </ol>
      <div class="card mb-4">
        <div class="card-header">
          <i class="fas fa-table me-1"></i>
          Data User
          <?php if($_SESSION['level']!= "guru" && $_SESSION['level']!= "kepsek") { ?>
          <a href="add-user.php" class=" btn btn-sm btn-primary float-end"><i class="fa-solid fa-plus me-2"></i>Tambah data</a>
          <?php } ?>
        </div>
        <div class="card-body">
          <table class="table table-bordered table-striped text-center" id="data_table">
            <thead>
              <th class="col col-1">No</th>
              <th>Username</th>
              <th>Nama</th>
              <th>Alamat</th>
              <th>Jabatan</th>
              <?php if($_SESSION['level'] == "kepala-lab"){ ?>
              <th>Email</th>
              <th>Aksi</th>
              <?php } ?>
            </thead>
            <tbody>
              <?php
              $no = 1;
              $querylab = mysqli_query($koneksi, "SELECT * FROM tbl_user");
              while ($data = mysqli_fetch_array($querylab)) { ?>
                <tr>
                  <th><?= $no++; ?></th>
                  <th><?= $data["username"]; ?></th>
                  <th><?= $data["nama"]; ?></th>
                  <th><?= $data["alamat"]; ?></th>
                  <th><?= $data["level"]; ?></th>
                  <?php if($_SESSION['level'] == "kepala-lab"){ ?>
                  <th><?= $data["email"]; ?></th>
                  <th>
                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#ModalEdit<?= $no; ?>">
                      <i class="fa-solid fa-pen"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#ModalDltd<?= $no ?>">
                      <i class="fa-solid fa-trash"></i>
                  </button>
                  
                </th>
                <?php include "modal.php"?>
                  <?php } ?>
                  <?php } ?>
                </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>
<?php

require_once "../templates/footer.php";


?>