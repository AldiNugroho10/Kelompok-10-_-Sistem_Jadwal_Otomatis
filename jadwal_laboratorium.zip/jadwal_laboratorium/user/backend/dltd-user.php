<?php 
session_start();

if (!isset($_SESSION['sslogin'])) {
    header("Location: ./auth/login.php");
    exit;
}

require_once "../../config.php";

if (isset($_POST['submit'])) {
    $id = $_POST['id_user'];

    // Hapus data dari tbl_user
    $resultUser = mysqli_query($koneksi, "DELETE FROM tbl_user WHERE id_user = $id");

    // Hapus data dari tbl_guru (jika ada)
    $resultGuru = mysqli_query($koneksi, "DELETE FROM tbl_guru WHERE id_user = $id");

    if ($resultUser && $resultGuru) {
        $_SESSION['succses'] = '';
    } else {
        $_SESSION['failed'] = '';
    }
    header('location: ../user.php');
}
