<?php

session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./auth/login.php");
  exit;
}

require_once "../../config.php";

if (isset($_POST['submit'])) {
  $id = $_POST['id_user'];
  $username = htmlspecialchars($_POST['username']);
  $alamat = htmlspecialchars($_POST['alamat']);
  $email = htmlspecialchars($_POST['email']);

  $query = "UPDATE tbl_user SET 
  username = '$username',
  alamat = '$alamat',
  email = '$email'

  WHERE id_user = $id";

  // Memperbarui data di database
  mysqli_query($koneksi, $query);

  $_SESSION['edit'] = 'data berhasil di edit';
  header('location: ../user.php');
}


require_once "../../templates/footer.php";
