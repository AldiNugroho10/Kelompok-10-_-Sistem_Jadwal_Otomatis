<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./auth/login.php");
  exit;
}

require_once "config.php";

$title = "kepala Lab SMKN 1 RAWAMERTA";

require_once "./templates/header.php";
require_once "./templates/navbar.php";
require_once "./templates/sidebar.php";

if (isset($_SESSION["edit"])) {
  echo "<script>
  alert('data berhasil di edit');
  </script>";
  unset($_SESSION["edit"]);
} elseif (isset($_SESSION["succses"])) {
  echo "<script>
  alert('data berhasil di hapus');
  </script>";
  unset($_SESSION["succses"]);
} elseif (isset($_SESSION["failed"])) {
  echo "<script>
  alert('data gagal di hapus');
  </script>";
  unset($_SESSION["failed"]);
}

?>


<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid px-4">
      <h1 class="mt-2">Jadwal Pelajaran</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Jadwal Pelajaran</li>
      </ol>
      <div class="card mb-4">
        <div class="card-header">
          <i class="fas fa-table me-1"></i>
          Data Mata Pelajaran
          <a href="add-guru.php" class=" btn btn-sm btn-primary float-end"><i class="fa-solid fa-plus me-2"></i>Tambah data</a>
        </div>
        <div class="card-body">
          <table class="table table-bordered table-striped text-center" id="data_table">
            <thead>
              <th class="col col-1">No</th>
              <th>Hari</th>
              <th>Mata Pelajaran</th>
              <th>Nama Guru</th>
              <th>Jam</th>
              <th>Kelas</th>
              <th>Aksi</th>
            </thead>
            <tbody>
              <?php
              $no = 1;
              $query = "SELECT
              tbl_jadwal.id,
              tbl_jadwal.id_hari,
              tbl_jadwal.id_mata_pelajaran,
              tbl_jadwal.id_guru,
              tbl_jadwal.jam,
              tbl_hari.nama_hari,
              tbl_matpel.nama_matpel,
              tbl_guru.nama_guru,
              tbl_kelas.nama_kelas
            FROM
              tbl_jadwal
            JOIN
              tbl_hari
            ON
              tbl_jadwal.id_hari = tbl_hari.id
            JOIN
              tbl_matpel
            ON
              tbl_jadwal.id_mata_pelajaran = tbl_matpel.id
            JOIN
              tbl_guru
            ON
              tbl_jadwal.id_guru = tbl_guru.id
            JOIN
              tbl_kelas
            ON
              tbl_jadwal.id_kelas = tbl_kelas.id
            ";
              $result = mysqli_query($koneksi, $query);
              foreach ($result as $data) { ?>
                <tr>
                  <th><?= $no++; ?></th>
                  <td><?= $data["nama_hari"]; ?></td>
                  <td><?= $data["nama_matpel"]; ?></td>
                  <td><?= $data["nama_guru"]; ?></td>
                  <td><?= $data["jam"]; ?></td>
                  <td><?= $data["nama_kelas"]; ?></td>
                  <td>
                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#ModalEdit<?= $no; ?>">
                      <i class="fa-solid fa-pen"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#ModalDltd<?= $no ?>">
                      <i class="fa-solid fa-trash"></i>
                    </button>
                  </td>
                  <?php include './modal.php'; ?>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>
<?php

require_once "./templates/footer.php";


?>