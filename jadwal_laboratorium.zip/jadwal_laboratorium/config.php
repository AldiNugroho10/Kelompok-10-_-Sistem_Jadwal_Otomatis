<?php 


//buat koneksi
$koneksi = mysqli_connect("localhost", "root", "", "backend");

// if ($koneksi) {
//   # code...
//   echo "koneksi berhasil";
// } else {
//   # code...
//   echo "koneksi gagal";
// }

// url induk
define('BASE_URL',  'http://localhost:6969/jadwal_laboratorium/');
