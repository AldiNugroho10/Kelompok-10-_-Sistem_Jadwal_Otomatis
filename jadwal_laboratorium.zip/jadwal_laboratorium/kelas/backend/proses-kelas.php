<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}

require_once "../../config.php";

if (isset($_POST['submit'])) {
  $nama = trim(htmlspecialchars($_POST['nama_kelas']));

  // Lakukan validasi data jika diperlukan

  // Format query dengan benar
  $query = "INSERT INTO tbl_kelas (nama_kelas) VALUES ('$nama')";

  // Eksekusi query
  $result = mysqli_query($koneksi, $query);

  if ($result) {
    echo "<script>
                  alert('Data Berhasil di Simpan');
              </script>";
    header('location: ../kelas.php');
  } else {
    echo "Error: " . mysqli_error($koneksi);
    header("Location : ../add-kelas.php");
  }
}
