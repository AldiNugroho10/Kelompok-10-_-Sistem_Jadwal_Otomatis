<?php

session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}

require_once "../../config.php";

if (isset($_POST['submit'])) {
  $id = $_POST['id'];
  $nama = htmlspecialchars($_POST['nama_kelas']);

  $query = "UPDATE tbl_kelas SET nama_kelas = '$nama' WHERE tbl_kelas.id = $id";


  // Memperbarui data di database
  mysqli_query($koneksi, $query);

  $_SESSION['edit'] = 'Data berhasil di edit';
  header('location: ../kelas.php');
}


require_once "../templates/footer.php";
