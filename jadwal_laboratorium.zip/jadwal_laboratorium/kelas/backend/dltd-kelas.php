<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
	header("Location: ./auth/login.php");
	exit;
}

require_once "../../config.php";

if (isset($_POST['submit'])) {
	$id = $_POST['id_kelas'];

	$result = mysqli_query($koneksi, "DELETE FROM tbl_kelas WHERE id = $id");

	if ($result) {
		$_SESSION['succses'] = 'Data Berhasil di Hapus';
	} else {
		$_SESSION['failed'] = 'Data Gagal di Hapus';
	}
	header('location: ../kelas.php');
}
