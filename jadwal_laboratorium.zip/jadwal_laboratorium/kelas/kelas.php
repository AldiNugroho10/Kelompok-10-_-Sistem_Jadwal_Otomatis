<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
// Redirect to the login page using BASE_URL
header("Location: ./../auth/login.php");
exit;


}
require_once "../config.php";

$title = "Daftar Kelas";

require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";


?>


<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid px-4">
      <h1 class="mt-2">Daftar Kelas</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Daftar Kelas</li>
      </ol>
      <div class="card mb-4">
        <div class="card-header">
          <i class="fas fa-table me-1"></i>
          Data Mata Pelajaran
          <!-- <a href="add-kelas.php" class=" btn btn-sm btn-primary float-end"><i class="fa-solid fa-plus me-2"></i>Tambah data</a> -->
          <?php if($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek"){?>
          <button type="button" class=" btn btn-sm btn-primary float-end" data-bs-toggle="modal" data-bs-target="#ModalAdd"><i class="fa-solid fa-plus me-2"></i>Tambah data</button>
          <?php } ?>
        </div>
        <?php include_once __DIR__."/modal/modal-add.php" ?>
        <div class="card-body">
          
          <table class="table table-bordered table-striped text-center" id="data_table">
            <thead>
              <th class="col col-1">No</th>
              <th>Kelas</th>
              <?php if($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek"){?>
              <th>Aksi</th>
              <?php } ?>
            </thead>
            <tbody>
              <?php
              $no = 1;
              $query = "SELECT * FROM tbl_kelas";
              $result = mysqli_query($koneksi, $query);
              foreach ($result as $data) { ?>
                <tr>
                  <th><?= $no++; ?></th>
                  <td><?= $data["nama_kelas"]; ?></td>
                  <?php if($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek"){?>
                  <td>
                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#ModalEdit<?= $no; ?>">
                      <i class="fa-solid fa-pen"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#ModalDltd<?= $no ?>">
                      <i class="fa-solid fa-trash"></i>
                    </button>
                  </td>
                  <?php
                  include './modal.php';
                  ?>
                </tr>
              <?php } ?>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>

<?php

require_once "../templates/footer.php";


?>