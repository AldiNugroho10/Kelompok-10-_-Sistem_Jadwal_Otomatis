<div class="modal fade" id="ModalAdd" tabindex="-1" aria-labelledby="ModalAdd" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="./backend/proses-kelas.php" method="post">
        <input type="hidden" name="id" value="<?= $data['id_kelas'] ?>">
        <div class="modal-header">
          <h5 class="modal-title fs-5" id="exampleModalLabel">Tambah Kelas </h5>
          <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" style="background-color: #f9f9f9;">
          <label for="nama_kelas" class="form-label">Kelas :</label>
          <input class="form-control" type="text" name="nama_kelas" id="nama_kelas" required>
        </div>
        <div class="modal-footer" style="background-color: #f9f9f9;">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
      </form>
    </div>
  </div>
</div>
</div>