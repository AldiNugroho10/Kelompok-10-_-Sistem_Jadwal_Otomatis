<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./auth/login.php");
  exit;
}

require_once "config.php";

$title = "Sistem Lab SMKN 1 RAWAMERTA";

require_once "./templates/header.php";
require_once "./templates/navbar.php";
require_once "./templates/sidebar.php";



?>
<div id="layoutSidenav_content">
  <main class="container fluid px-4  mt-2">
    <h1 class=" mb-2">Daftar Jadwal</h1>
    <?php if ($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek") { ?>
            <button type="button" class=" btn btn-sm btn-primary float-end" data-bs-toggle="modal" data-bs-target="#ModalAdd"><i class="fa-solid fa-plus me-2"></i>Tambah data</button>
            <?php include_once "../modal/modal-add.php" ?>
          <?php } ?>
    <hr>
    <ol class="breadcrumb mb-2">
      <li class="breadcrumb-item active">Daftar Jadwal Ruangan</li>
    </ol>
    <div class="row row-cols-1 row-cols-md-2 g-6x">
      <div class="col">
        <div class="dashboard-card card m-4">
          <img src="assets/image/lb2.jpg" class="card-img-top" alt="TKJ 1">
          <div class="card-body">
            <h5 class="card-title">TKJ 1</h5>
            <p class="card-text">Ruangan Lab  1</p>
            <a href="<?= BASE_URL ?>jadwal/lab1/" class="btn btn-primary">Detail</a>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="dashboard-card card m-4">
          <img src="assets/image/lb1.jpg" class="card-img-top" alt="TKJ 2">
          <div class="card-body">
            <h5 class="card-title">TKJ 2</h5>
            <p class="card-text">Ruangan Lab 2</p>
            <a href="#" class="btn btn-primary">Detail</a>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="dashboard-card card m-4">
          <img src="assets/image/lb.jpg" class="card-img-top" alt="TKJ 3">
          <div class="card-body">
            <h5 class="card-title">TKJ 3</h5>
            <p class="card-text">Ruangan Lab 3</p>
            <a href="#" class="btn btn-primary">Detail</a>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="dashboard-card card m-4">
          <img src="assets/image/lb4.jpg" class="card-img-top" alt="TKJ 4">
          <div class="card-body">
            <h5 class="card-title">TKJ 4</h5>
            <p class="card-text">Ruangan Lab 4</p>
            <a href="#" class="btn btn-primary">Detail</a>
          </div>
        </div>
      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>
<?php

require_once "./templates/footer.php";


?>