<div class="modal fade" id="ModalAdd" tabindex="-1" aria-labelledby="ModalAdd" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="./backend/proses-guru.php" method="post">
        <input type="hidden" name="id" value="<?= $data['id_guru'] ?>">
        <div class="modal-header">
          <h5 class="modal-title fs-5" id="exampleModalLabel">Tambah Guru </h5>
          <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-2">
            <label for="nip" class="form-label">Nip :</label>
            <input class="form-control" type="text" name="nrp" id="nrp" required>
          </div>
          <div class="mb-2">
            <label for="nama_guru" class="form-label">Nama :</label>
            <input class="form-control" type="text" name="nama_guru" id="nama_guru" required>
          </div>
          <div class="mb-2">
            <label for="alamat" class="form-label">Alamat :</label>
            <input class="form-control" type="text" name="alamat" id="alamat" required>
          </div>
          <div class="mb-2">
            <label for="email" class="form-label">Email :</label>
            <input class="form-control" type="text" name="email" id="email" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
      </form>
    </div>
  </div>
</div>
</div>