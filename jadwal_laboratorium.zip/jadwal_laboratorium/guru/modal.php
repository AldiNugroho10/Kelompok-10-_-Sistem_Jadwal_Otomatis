<?php 
include __DIR__."/modal/modal-dltd.php";
include __DIR__."/modal/modal-edit.php";
include __DIR__."/modal/modal-add.php";

?>