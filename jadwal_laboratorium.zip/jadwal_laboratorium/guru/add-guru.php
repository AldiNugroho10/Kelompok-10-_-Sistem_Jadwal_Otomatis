<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}


require_once "../config.php";

$title = "Tambah Guru - SMKN 1 RAWAMERTA";
require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";

?>

<div id="layoutSidenav_content">
  <main class="container mt-4">
    <h1 class=" mb-4">Tambah Data Guru</h1>
    <ol class="breadcrumb mb-4">
      <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
      <li class="breadcrumb-item active"><a href="guru.php">Data Guru</a></li>
      <li class="breadcrumb-item">Tambah Guru</li>
    </ol>
    <form action="./backend/proses-guru.php" method="POST">
      <div class="card">
        <div class="card-header align-items-center">
          <span class="h5 mx-2">Tambah Data <i class="fa-solid fa-square-plus"> </i></span>
          <button type="submit" name="simpan" class="btn btn-primary float-end">Simpan <i class="fa-solid fa-floppy-disk mx-1"></i></button>
          <button type="reset" name="reset" class="btn btn-danger float-end me-2">Reset <i class="fa-solid fa-xmark mx-1"></i></button>
        </div>
        <div class="card-body">
          <div class="row mb-3">
            <label for="nip" class="col-sm-2 col-form-label" autocomplete="off">Nip</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <input type="number" class="form-control border-0 border-bottom" id="nip" name="nip" maxlength="20" autocomplete="off">
            </div>
          </div>
          <div class="row mb-3">
            <label for="nama_guru" class="col-sm-2 col-form-label">Nama Lengkap</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <input type="text" class="form-control border-0 border-bottom" id="nama_guru" name="nama_guru" autocomplete="off">
            </div>
          </div>
          <div class="row mb-3">
            <label for="jjm" class="col-sm-2 col-form-label" autocomplete="off">Jumlah Jam Mengajar</label>
            <div class="col-sm-1 col-form-label">:</div>
            <div class="col-sm-9" style="margin-left: -80px;">
              <input type="text" class="form-control border-0 border-bottom" id="jjm" name="jjm" autocomplete="off"></input>
            </div>
          </div>
    </form>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>
<?php

require_once "../templates/footer.php";


?>