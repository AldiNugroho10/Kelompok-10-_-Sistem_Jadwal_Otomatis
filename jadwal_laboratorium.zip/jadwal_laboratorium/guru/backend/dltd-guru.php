<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
	header("Location: ./../auth/login.php");
	exit;
}

require_once "../../config.php";

if (isset($_POST['submit'])) {
	$id = $_POST['id_guru'];

	$result = mysqli_query($koneksi, "DELETE tbl_guru, tbl_user
	FROM tbl_guru
	JOIN tbl_user ON tbl_guru.id_user = tbl_user.id_user
	WHERE tbl_guru.id = $id;
	");

	if ($result) {
		$_SESSION['succses'] = '';
	} else {
		$_SESSION['failed'] = '';
	}
	header('location: ../guru.php');
}
