<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}

require_once "../../config.php";

if (isset($_POST['simpan'])) {
  $nama = trim(htmlspecialchars($_POST['nama_guru']));
  $nrp = trim(htmlspecialchars($_POST['nrp']));
  $jjm = trim(htmlspecialchars($_POST['alamat']));
  $email = trim(htmlspecialchars($_POST['email']));
  $alamat = trim(htmlspecialchars($_POST['alamat']));

  // Lakukan validasi data jika diperlukan
  // Hindari SQL injection dengan membersihkan input
  $username = mysqli_real_escape_string($koneksi, $nama);
  $password = password_hash("default_password", PASSWORD_DEFAULT);
  $kode = mysqli_real_escape_string($koneksi, $kode);

  // Format query dengan data yang telah dibersihkan
  $query = "INSERT INTO tbl_user (username, password, nama, alamat, email, kode, level, nrp)
            VALUES ('$username', '$password', '$nama', '$alamat', '$email', '$kode', 'guru', '$nrp')";

  // Eksekusi query
  $result = mysqli_query($koneksi, $query);

  if ($result) {
    echo "<script>
                  alert('Data Berhasil di Simpan');
              </script>";
    header('location: ../guru.php');
  } else {
    echo "Error: " . mysqli_error($koneksi);
    header("Location: ../add-guru.php");
  }
}

// Tutup koneksi ke database jika diperlukan
mysqli_close($koneksi);
?>
