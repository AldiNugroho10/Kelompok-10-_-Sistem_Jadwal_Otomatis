<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}

require_once "./../config.php";

$title = "Daftar Guru";

require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";

?>


<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid px-4">
      <h1 class="mt-2">Daftar Guru</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Daftar Guru</li>
      </ol>
      <div class="card mb-4">
        <div class="card-header">
          <i class="fas fa-table me-1"></i>
          Data Mata Pelajaran
          <!-- <?php if ($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek") { ?>
            <a href="add-guru.php" class=" btn btn-sm btn-primary float-end"><i class="fa-solid fa-plus me-2"></i>Tambah data</a>
          <?php } ?> -->
        </div>
        <div class="card-body">
          <table class="table table-bordered table-striped text-center" id="data_table">
            <thead>
              <th class="col col-1">No</th>
              <th>NIP</th>
              <th>Nama Guru</th>
              <th>Alamat</th>
              <th>Jumlah Jam Mengajar</th>
              <?php if ($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek") { ?>
              <th>Email</th>
                <th>Aksi</th>
              <?php } ?>
            </thead>
            <tbody>
              <?php
              $no = 1;
              $querylab = mysqli_query($koneksi, "SELECT *
              FROM tbl_guru
              JOIN tbl_user ON tbl_guru.id_user = tbl_user.id_user;
              ");
              while ($data = mysqli_fetch_array($querylab)) {
                // Only display rows with 'level' equal to 'kep-lab'
                // if ($data['level'] == 'guru') {
              ?>
                  <tr>
                    <th><?= $no++; ?></th>
                    <td><?= $data["nrp_guru"]; ?></td>
                    <td><?= $data["nama_guru"]; ?></td>
                    <td><?= $data["alamat"]; ?></td>
                    <td><?= $data["jjm"]; ?></td>
                    <?php if ($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek") { ?>
                      <td><?= $data["email"]; ?></td>

                      <td>
                        <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#ModalEdit<?= $no; ?>">
                          <i class="fa-solid fa-pen"></i>
                        </button>
                        <!-- <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#ModalDltd<?= $no ?>">
                          <i class="fa-solid fa-trash"></i>
                        </button> -->
                      </td>
                      <?php include './modal.php'; ?>
                  </tr>
                  <?php } ?>
                  <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>
<?php

require_once "../templates/footer.php";


?>