/*!
    * Start Bootstrap - SB Admin v7.0.7 (https://startbootstrap.com/template/sb-admin)
    * Copyright 2013-2023 Start Bootstrap
    * Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-sb-admin/blob/master/LICENSE)
    */
    // 
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }

        let menu = `<i class="ri-menu-3-line ri-2x"></i>`;
        let x = `<i class="ri-close-line ri-2x"></i>`;
        
        
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            sidebarToggle.innerHTML = (document.body.classList.contains('sb-sidenav-toggled')) ? menu : x;
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
            
        });
    }

});

// window.addEventListener('DOMContentLoaded', event => {

//     // Toggle the side navigation
//     const sidebarToggle = document.body.querySelector('#sidebarToggle');
//     const sidebarContent = document.body.querySelector('#sb-sidenav-toggled');

//     if (sidebarToggle && sidebarContent) {
//         // Uncomment Below to persist sidebar toggle between refreshes
//         // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
//         //     document.body.classList.toggle('sb-sidenav-toggled');
//         // }

//         sidebarToggle.addEventListener('click', event => {
//             event.preventDefault();
//             document.body.classList.toggle('sb-sidenav-toggled');
//             localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));

//             // Change content based on sidebar state
//             if (document.body.classList.contains('sb-sidenav-toggled')) {
//                 sidebarContent.textContent = 'Sidebar Toggled Content'; // Ganti teks sesuai keinginan
//             } else {
//                 sidebarContent.textContent = 'Sidebar Content'; // Ganti teks sesuai keinginan saat sidebar tidak aktif
//             }
//         });
//     }

// });
