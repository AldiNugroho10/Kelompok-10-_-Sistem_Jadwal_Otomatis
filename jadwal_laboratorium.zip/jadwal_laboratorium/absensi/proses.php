<!DOCTYPE html>
<html>
<head>
	<title>Rekap Absensi</title>
</head>
<body>
	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Rekap Absensi.xls");
	?>
 
	<center>
		<h1>Rekap Absensi</h1>
	</center>
 
	<table border="1">
		<tr>
			<th>No</th>
			<th>Hari</th>
			<th>Guru</th>
			<th>Tanggal</th>
			<th>Status</th>
		</tr>
		<?php 
		// koneksi database
		$koneksi = mysqli_connect("localhost","root","","backend");
 
		// menampilkan data pegawai
		$data = mysqli_query($koneksi,"SELECT 
    tbl_jadwal.*,
    tbl_hari.nama_hari,
    tbl_matpel.nama_matpel,
    tbl_guru.nama_guru,
    tbl_kelas.nama_kelas,
    tbl_absensi.nama_absensi
  FROM 
    tbl_jadwal
  INNER JOIN 
    tbl_hari ON tbl_jadwal.id_hari = tbl_hari.id
  INNER JOIN 
    tbl_matpel ON tbl_jadwal.id_mata_pelajaran = tbl_matpel.id
  INNER JOIN 
    tbl_guru ON tbl_jadwal.id_guru = tbl_guru.id
  INNER JOIN 
    tbl_kelas ON tbl_jadwal.id_kelas = tbl_kelas.id
  INNER JOIN 
    tbl_absensi ON tbl_jadwal.id_absensi = tbl_absensi.id
  WHERE 
    MONTH(tbl_jadwal.tanggal) = MONTH(CURDATE())
    AND YEAR(tbl_jadwal.tanggal) = YEAR(CURDATE())
    ORDER BY tbl_jadwal.tanggal ASC, tbl_hari.id, tbl_jadwal.jam;");
		$no = 1;
		while($d = mysqli_fetch_array($data)){
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $d['nama_hari']; ?></td>
			<td><?php echo $d['nama_guru']; ?></td>
			<td><?php echo $d['tanggal']; ?></td>
			<td><?php echo $d['nama_absensi']; ?></td>
		</tr>
		<?php 
		}
		?>
	</table>
</body>
</html>