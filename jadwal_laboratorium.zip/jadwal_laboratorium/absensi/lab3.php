<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}
require_once "../config.php";

$title = "Laboratorium 3";

require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";


?>

<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid px-4">
      <h1 class="mt-2">Absensi</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Absensi</li>
      </ol>
      <div class="card mb-4">
        <div class="card-header">
          <i class="fas fa-table me-1"></i>
          Data Mata Pelajaran
          <?php if ($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek") { ?>
            <button type="button" class=" btn btn-sm btn-primary float-end" data-bs-toggle="modal" data-bs-target="#ModalAdd"><i class="fa-solid fa-plus me-2"></i>Tambah data</button>
            <?php include_once "../modal/modal-add.php" ?>
          <?php } ?>
        </div>
        <div class="card-body">
          <table class="table table-bordered table-striped text-center" id="data_table">
            <thead>
              <th>Hari</th>
              <th>Mata Pelajaran</th>
              <th>Nama Guru</th>
              <th>Jam</th>
              <th>Kelas</th>
              <?php if ($_SESSION['level'] == "guru") { ?>
                <th>Absensi</th>
              <?php } ?>
              <?php if ($_SESSION['level'] != "guru") { ?>
                <th>Status</th>
              <?php } ?>
              <?php if ($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek") { ?>
                <th>Aksi</th>
              <?php } ?>
            </thead>
            <tbody>
              <?php
              $no = 1;
              $query = "SELECT tbl_jadwal.*, tbl_hari.nama_hari, tbl_matpel.nama_matpel, tbl_guru.nama_guru, tbl_kelas.nama_kelas, tbl_absensi.nama_absensi FROM tbl_jadwal INNER JOIN tbl_hari ON tbl_jadwal.id_hari = tbl_hari.id INNER JOIN tbl_matpel ON tbl_jadwal.id_mata_pelajaran = tbl_matpel.id INNER JOIN tbl_guru ON tbl_jadwal.id_guru = tbl_guru.id INNER JOIN tbl_kelas ON tbl_jadwal.id_kelas = tbl_kelas.id INNER JOIN tbl_absensi ON tbl_jadwal.id_absensi = tbl_absensi.id WHERE tbl_jadwal.id_ruang = 3 ORDER BY tbl_hari.id, tbl_jadwal.jam;";

              $result = mysqli_query($koneksi, $query);

              function getStatusBadgeClass($nama_absensi)
              {
                switch ($nama_absensi) {
                  case "hadir":
                    return "bg-success";
                  case "sakit":
                    return "bg-warning";
                  case "alfa":
                    return "bg-danger";
                  case "belum_absen":
                    return "bg-secondary";
                  case "izin":
                    return "bg-info";
                  default:
                    return "bg-secondary";
                }
              }
              foreach ($result as $data) {

              ?>
                <?php if ($_SESSION['ssUser'] == $data['nama_guru']) { ?>
                  <tr>
                    <td><?= $data["nama_hari"]; ?></td>
                    <td><?= $data["nama_matpel"]; ?></td>
                    <td><?= $data["nama_guru"]; ?></td>
                    <td><?= date('H:i', strtotime($data["jam"])); ?></td>
                    <td><?= $data["nama_kelas"]; ?></td>
                    <?php if ($_SESSION['level'] != "guru") { ?>
                      <td>
                        <span class="badge <?= getStatusBadgeClass($data["nama_absensi"]); ?>">
                          <?= $data["nama_absensi"] == "belum_absen" ? "Belum Absensi" : $data["nama_absensi"]; ?>
                        </span>
                      </td>
                    <?php } ?>
                    <?php if ($_SESSION['level'] == "guru") { ?>
                      <td>
                        <?php if ($_SESSION['ssUser'] == $data['nama_guru']) { ?>
                          <?php if ($data['nama_absensi'] == 'belum_absen') { ?>
                            <a type="button" class="btn btn-primary btn-sm" href="absensi.php?id_jadwal=<?= isset($data['id_jadwal']) ? base64_encode($data['id_jadwal']) : '' ?>">Submit attendance</a>
                          <?php } else { ?>
                            <span class="badge <?= getStatusBadgeClass($data["nama_absensi"]); ?>">
                              <?= $data["nama_absensi"]; ?>
                            </span>
                          <?php } ?>
                      </td>
                    <?php } ?>
                  <?php } ?>
                  <?php if ($_SESSION['level'] != "guru" && $_SESSION['level'] != "kepsek") { ?>
                    <td>
                      <button t ype="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#ModalEdit<?= $no; ?>">
                        <i class="fa-solid fa-pen"></i>
                      </button>
                      <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#ModalDltd<?= $no ?>">
                        <i class="fa-solid fa-trash"></i>
                      </button>
                    </td>
                    <?php include "../modal.php" ?>
                  </tr>
                <?php } ?>
              <?php } ?>
            <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>
<?php
require_once "../templates/footer.php";
?>