<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
  exit;
}

require_once "./../config.php";

$title = "Data Absensi";

// Check if the filter form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $selectedMonth = isset($_POST['selected_month']) ? $_POST['selected_month'] : '';
  $selectedYear = isset($_POST['selected_year']) ? $_POST['selected_year'] : '';

  // Build the query with the selected month and year
  $query = "SELECT 
  tbl_jadwal.*,
  tbl_hari.nama_hari,
  tbl_matpel.nama_matpel,
  tbl_guru.nama_guru,
  tbl_kelas.nama_kelas,
  tbl_absensi.nama_absensi
FROM 
  tbl_jadwal
INNER JOIN 
  tbl_hari ON tbl_jadwal.id_hari = tbl_hari.id
INNER JOIN 
  tbl_matpel ON tbl_jadwal.id_mata_pelajaran = tbl_matpel.id
INNER JOIN 
  tbl_guru ON tbl_jadwal.id_guru = tbl_guru.id
INNER JOIN 
  tbl_kelas ON tbl_jadwal.id_kelas = tbl_kelas.id
INNER JOIN 
  tbl_absensi ON tbl_jadwal.id_absensi = tbl_absensi.id
WHERE 
  MONTH(tbl_jadwal.tanggal) = $selectedMonth
  AND YEAR(tbl_jadwal.tanggal) = $selectedYear
ORDER BY tbl_jadwal.tanggal ASC, tbl_hari.id, tbl_jadwal.jam";
} else {
  // Default query for the current month and year
  $query = "SELECT 
  tbl_jadwal.*,
  tbl_hari.nama_hari,
  tbl_matpel.nama_matpel,
  tbl_guru.nama_guru,
  tbl_kelas.nama_kelas,
  tbl_absensi.nama_absensi
FROM 
  tbl_jadwal
INNER JOIN 
  tbl_hari ON tbl_jadwal.id_hari = tbl_hari.id
INNER JOIN 
  tbl_matpel ON tbl_jadwal.id_mata_pelajaran = tbl_matpel.id
INNER JOIN 
  tbl_guru ON tbl_jadwal.id_guru = tbl_guru.id
INNER JOIN 
  tbl_kelas ON tbl_jadwal.id_kelas = tbl_kelas.id
INNER JOIN 
  tbl_absensi ON tbl_jadwal.id_absensi = tbl_absensi.id
WHERE 
  MONTH(tbl_jadwal.tanggal) = MONTH(CURDATE())
  AND YEAR(tbl_jadwal.tanggal) = YEAR(CURDATE())
  ORDER BY tbl_jadwal.tanggal ASC, tbl_hari.id, tbl_jadwal.jam;";
}

require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";
?>



<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid px-4">
      <h1 class="mt-2">Data Absensi</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Data Absensi Bulanan</li>
      </ol>

      <!-- Filter Form -->
      <form method="post" action="">
        <label for="selected_month" class="form-label">Cari Bulan:</label>
        <select name="selected_month" class="form-select" id="selected_month" required>
          <option value="" selected>--Pilih Bulan--</option>
          <?php
          for ($month = 1; $month <= 12; $month++) {
            $selected = ($month == date('n')) ? '' : '';
            echo "<option value='$month' $selected>" . date('F', mktime(0, 0, 0, $month, 1)) . "</option>";
          }
          ?>
        </select>

        <label for="selected_year" class="form-label">Cari Tahun:</label>
        <select name="selected_year" class="form-select" id="selected_year" required>
          <option value="" selected>--Pilih Tahun--</option>
          <?php
          $currentYear = date('Y');
          for ($year = $currentYear - 5; $year <= $currentYear + 5; $year++) {
            $selected = ($year == $currentYear) ? '' : '';
            echo "<option value='$year' $selected>$year</option>";
          }
          ?>
        </select>

        <button type="submit" class="btn btn-primary mt-4 mb-4 me-1">Filter</button>
        <a href="proses.php">
          <button type="button" class="btn btn-success"><i class="fa-solid fa-print me-2"></i>Expor Data</button>
        </a>
      </form>


      <div class="card mb-4">
        <div class="card-header">
          <i class="fas fa-table me-1"></i>
          Data Mata Pelajaran
        </div>
        <div class="card-body">
          <table class="table table-bordered table-striped text-center" id="data_table">
            <thead>
              <th>Hari</th>
              <th>Guru</th>
              <th>Tanggal</th>
              <th>Absensi</th>
            </thead>
            <tbody>
              <?php
              $result = mysqli_query($koneksi, $query);
              foreach ($result as $data) { ?>
                <tr>
                  <td><?= $data["nama_hari"]; ?></td>
                  <td><?= $data["nama_guru"]; ?></td>
                  <td><?= $data["tanggal"]; ?></td>
                  <td><?= $data["nama_absensi"]; ?></td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>

<?php
require_once "../templates/footer.php";
?>