<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
    header("Location: ./../auth/login.php");
    exit;
}

require_once "../config.php";

$title = "Absensi";

require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";
?>

<div id="layoutSidenav_content">
    <main class="container-fluid px-4 mt-2">
        <h1 class="mt-2">Absensi Guru</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="index.php">Absensi</a></li>
            <li class="breadcrumb-item active">Absensi Guru</li>
        </ol>

        <div class="row">
            <?php
            // Lab information
            $labs = [
                ['title' => 'TKJ 1', 'description' => 'Ruangan Lab 1', 'url' => BASE_URL . 'absensi/lab1.php'],
                ['title' => 'TKJ 2', 'description' => 'Ruangan Lab 2', 'url' => BASE_URL . 'absensi/lab2.php'],
                ['title' => 'TKJ 3', 'description' => 'Ruangan Lab 3', 'url' => BASE_URL . 'absensi/lab3.php'],
                ['title' => 'TKJ 4', 'description' => 'Ruangan Lab 4', 'url' => BASE_URL . 'absensi/lab4.php'],
            ];

            // Loop through labs
            foreach ($labs as $lab) :
            ?>
                <div class="col-sm-6 mb-3 mb-sm-0">
                    <div class="card border-primary mt-4">
                        <div class="card">
                            <div class="card-body mt-2">
                                <h5 class="card-title"><strong><?= $lab['title'] ?></strong></h5>
                                <p class="card-text"><?= $lab['description'] ?></p>
                                <a href="<?= $lab['url'] ?>" class="btn btn-primary">Detail</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <footer class="py-3 bg-light border mt-4 text-center">
        <div class="container-fluid px-4">
            <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
        </div>
    </footer>
</div>

<?php
require_once "../templates/footer.php";
?>
