<?php
session_start();

if (!isset($_SESSION['sslogin'])) {
  header("Location: ./../auth/login.php");
    exit;
}

require_once "../config.php";

$alertMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_absensi = isset($_POST['nama_absensi']) ? $_POST['nama_absensi'] : '';
    $tanggal = isset($_POST['tanggal']) ? $_POST['tanggal'] : '';

    $id_jadwal = base64_decode($_GET['id_jadwal']);

    $id_absensi_query = "SELECT id FROM tbl_absensi WHERE nama_absensi = '$nama_absensi'";
    $id_absensi_result = mysqli_query($koneksi, $id_absensi_query);

    if ($id_absensi_result) {
        $id_absensi_row = mysqli_fetch_assoc($id_absensi_result);
        $id_absensi = $id_absensi_row['id'];

        $updateStatusQuery = "UPDATE tbl_jadwal SET tanggal = '$tanggal', id_absensi = $id_absensi WHERE id_jadwal = $id_jadwal";

        if (mysqli_query($koneksi, $updateStatusQuery)) {
            $alertMessage = "Absen Berhasil!";
            echo "<script>alert('$alertMessage');</script>";
            echo "<script>window.location.href = '" . BASE_URL . "/absensi/lab.php';</script>";
        } else {
            $alertMessage = "Absen Gagal!: " . mysqli_error($koneksi);
            echo "<script>alert('$alertMessage');</script>";
            echo "<script>window.location.href = '" . BASE_URL . "';</script>";
        }
    } else {
        $alertMessage = "Error retrieving id_absensi: " . mysqli_error($koneksi);
        echo "<script>alert('$alertMessage');</script>";
        echo "<script>window.location.href = '" . BASE_URL . "';</script>";
    }
}

$title = "Sistem Lab SMKN 1 RAWAMERTA";
require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";
?>


<div id="layoutSidenav_content">
  <main>
    <div class="container-fluid px-4">
      <h1 class="mt-2">Absensi Guru</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
        <li class="breadcrumb-item active"><a href="index.php">Absensi</a></li>
        <li class="breadcrumb-item active">Absensi Guru</li>

      </ol>
      <div>
        <div class="row d-flex align-items-center justify-content-center">
          <div class="col-md-4 text-center">
            <img src="../assets/image/absensi.jpg" alt="" class="img-fluid" style="max-width: 300px;">
          </div>
          <div class="col-md-6">
            <div class="card shadow" style="max-width: 500px;">
              <div class="card-body">
                <form method="post" action="">
                  <div class="mb-3">
                    <label for="status" class="form-label">Status:</label>
                    <select name="nama_absensi" class="form-select" id="nama_absensi" required>
                      <option value="" selected>Pilih Status</option>
                      <option value="hadir">Hadir</option>
                      <option value="sakit">Sakit</option>
                      <option value="izin">Izin</option>
                      <option value="alfa">Alfa</option>
                      <!-- <option value="belum_absen">Belum Absen</option> -->
                    </select>
                  </div>
                  <input type="hidden" class="date" name="tanggal" value="<?= date('Y-m-d') ?>">
                  <button type="submit" class="btn btn-primary">
                    <i class="fas fa-check"></i> Absen
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <footer class="py-3 bg-light border mt-4 text-center">
    <div class="container-fluid px-4">
      <div class="text-muted">Copyright &copy; SMKN 1 RAWAMERTA <?= date('Y') ?></div>
    </div>
  </footer>
</div>

<?php
require_once "../templates/footer.php";
?>