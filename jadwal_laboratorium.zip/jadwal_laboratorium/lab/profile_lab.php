<?php

require_once "../config.php";

$z = "Lab SMKN 1 RAWAMERTA";
require_once "../templates/header.php";
require_once "../templates/navbar.php";
require_once "../templates/sidebar.php";
?>

<div id="layoutSidenav_content">
  <main>
    <div class="container mt-4">
      <h1 class=" mb-4">Laboratorium</h1>
      <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
        <li class="breadcrumb-item active">Profile Lab</li>
      </ol>
      <div class="card">
        <div class="card-header">
          <span class="h4">Data Laboratorium<i class="fa-solid fa-pen-to-square mx-1"></i></span>
          <button type="submit" name="simpan" class="btn btn-primary float-end mx-2"><i class="fa-solid fa-floppy-disk mx-2"></i>Simpan</button>
          <button type="reset" name="reset" class="btn btn-danger float-end me-2"><i class="fa-solid fa-xmark mx-1"></i> Reset</button>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-4 text-center px-5">
              <img src="assets/image/sekolah.jpg" alt="gambar Lab" class="mb-3" width="100%">
              <input type="file" name="image" class="form-control form-control-sm">
              <small class="text-secondary">Pilih gambar PNG, JPG atau JPEG Max 1MB</small></small>
            </div>
            <div class="col-8">
              <div class="row mb-3">
                <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-2 col-form-label">:</div>
                <div class="col-sm-9" style="margin-left: -110px;">
                  <input type="text" class="form-control border-0 border-bottom" id="nama" name="nama" value="" placeholder="Ruang Laboratorium" required>
                </div>
                <div class="row mb-3">
                  <label for="nama" class="col-sm-2 col-form-label">Email</label>
                  <div class="col-sm-2 col-form-label">:</div>
                  <div class="col-sm-9" style="margin-left: -100px;">
                    <input type="email" class="form-control border-0 border-bottom" id="email" name="email" value="" placeholder="Email Lab" required>
                  </div>
                  <div class="row mb-3">
                    <label for="name" class="col-sm-2 col-form-label">Status</label>
                    <label for="name" class="col-sm-1 col-form-label">:</label>
                    <div class="col-sm-1 col-form-label">:</div>
                    <div class="col-sm-9" style="margin-left: -80px;">
                      <select name="status" id="status" class="form-select border-0 border-bottom" required>
                        <option value="" selected>Status Ruangan Lab</option>
                        <option value="Terisi">Terisi</option>
                        <option value="Kosong">Kosong</option>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  </main>



  <?php

  require_once "../templates/footer.php";

  ?>